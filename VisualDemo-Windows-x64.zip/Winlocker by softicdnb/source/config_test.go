package main

import (
	"bytes"
	"encoding/binary"
	"os"
	"path/filepath"
	"testing"
)

func TestConfigRoundTripAndReexport(t *testing.T) {
	base := []byte("MZ-demo-original-binary")
	c := defaults()
	c.Body = "Русский текст\n引号 <script> & "
	c.Password = "пароль★"
	out, err := pack(base, c)
	if err != nil {
		t.Fatal(err)
	}
	gotBase, got, err := unpack(out)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(gotBase, base) || got == nil || *got != c {
		t.Fatal("config round trip mismatch")
	}
	c.Eye = "ВТОРАЯ ВЕРСИЯ"
	again, err := pack(out, c)
	if err != nil {
		t.Fatal(err)
	}
	gotBase, got, err = unpack(again)
	if err != nil || !bytes.Equal(gotBase, base) || *got != c {
		t.Fatal("reexport duplicated config or lost text")
	}
}

func TestRejectCorruptAndInvalidConfigs(t *testing.T) {
	for _, n := range []uint64{1 << 63, 1<<20 + 1, 1000} {
		var b [8]byte
		binary.LittleEndian.PutUint64(b[:], n)
		data := append(b[:], marker...)
		if _, _, err := unpack(data); err == nil {
			t.Fatalf("accepted corrupt length %d", n)
		}
	}
	for _, mutate := range []func(*Config){
		func(c *Config) { c.Password = "" }, func(c *Config) { c.Seconds = 0 }, func(c *Config) { c.Seconds = 31 }, func(c *Config) { c.Title = "bad\x00text" },
	} {
		c := defaults()
		mutate(&c)
		if _, err := pack([]byte("MZ"), c); err == nil {
			t.Fatal("accepted invalid config")
		}
	}
}

func TestExportNeverOverwrites(t *testing.T) {
	p := filepath.Join(t.TempDir(), "demo.exe")
	if err := writeExport(p, []byte("original")); err != nil {
		t.Fatal(err)
	}
	if err := writeExport(p, []byte("replacement")); err == nil {
		t.Fatal("overwrote an existing file")
	}
	got, err := os.ReadFile(p)
	if err != nil || string(got) != "original" {
		t.Fatal("existing file changed")
	}
}

func FuzzUnpack(f *testing.F) {
	f.Add([]byte("MZ"))
	b, _ := pack([]byte("MZ"), defaults())
	f.Add(b)
	f.Add(marker)
	f.Fuzz(func(t *testing.T, data []byte) { unpack(data) })
}
