//go:build windows

package main

import (
	"fmt"
	"math"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"syscall"
	"time"
	"unsafe"
)

var (
	user                               = syscall.NewLazyDLL("user32.dll")
	gdi                                = syscall.NewLazyDLL("gdi32.dll")
	kernel                             = syscall.NewLazyDLL("kernel32.dll")
	create                             = user.NewProc("CreateWindowExW")
	defproc                            = user.NewProc("DefWindowProcW")
	send                               = user.NewProc("SendMessageW")
	show                               = user.NewProc("ShowWindow")
	destroy                            = user.NewProc("DestroyWindow")
	invalidate                         = user.NewProc("InvalidateRect")
	getText                            = user.NewProc("GetWindowTextW")
	setText                            = user.NewProc("SetWindowTextW")
	messageBox                         = user.NewProc("MessageBoxW")
	instance                           uintptr
	builder, player, input, exitButton uintptr
	cfg                                = defaults()
	start                              time.Time
	lastBeep                           time.Time
	stage                              = -1
	invalidPassword                    bool
	fields                             = map[int]uintptr{}
	fonts                              = map[int]uintptr{}
	appBytes                           []byte
	preview                            bool
)

type rect struct{ L, T, R, B int32 }
type point struct{ X, Y int32 }
type msg struct {
	H       uintptr
	M       uint32
	W, L    uintptr
	Time    uint32
	Pt      point
	Private uint32
}
type wc struct {
	Size, Style                        uint32
	Proc                               uintptr
	ClsExtra, WndExtra                 int32
	Instance, Icon, Cursor, Background uintptr
	Menu, Name                         *uint16
	SmallIcon                          uintptr
}
type paint struct {
	DC              uintptr
	Erase           int32
	R               rect
	Restore, Update int32
	Reserved        [32]byte
}

func u(s string) *uint16      { return syscall.StringToUTF16Ptr(s) }
func rgb(r, g, b int) uintptr { return uintptr(r | g<<8 | b<<16) }
func makeWindow(class, title string, style uintptr, x, y, w, h int, parent, id uintptr) uintptr {
	result, _, _ := create.Call(0, uintptr(unsafe.Pointer(u(class))), uintptr(unsafe.Pointer(u(title))), style, uintptr(x), uintptr(y), uintptr(w), uintptr(h), parent, id, instance, 0)
	return result
}
func textOf(h uintptr) string {
	b := make([]uint16, 16002)
	n, _, _ := getText.Call(h, uintptr(unsafe.Pointer(&b[0])), uintptr(len(b)))
	return syscall.UTF16ToString(b[:int(n)])
}
func notify(s string) {
	messageBox.Call(builder, uintptr(unsafe.Pointer(u(s))), uintptr(unsafe.Pointer(u("Visual Demo Builder"))), 0)
}
func font(size int) uintptr {
	if h := fonts[size]; h != 0 {
		return h
	}
	face := "Consolas"
	height := size
	if size < 0 {
		face = "Segoe UI"
		height = -size
	}
	h, _, _ := gdi.NewProc("CreateFontW").Call(uintptr(height), 0, 0, 0, 400, 0, 0, 0, 1, 0, 0, 5, 0, uintptr(unsafe.Pointer(u(face))))
	fonts[size] = h
	return h
}
func control(class, text string, x, y, w, h int, id int, extra uintptr) uintptr {
	if class == "BUTTON" {
		extra |= 0x10000
	}
	c := makeWindow(class, text, 0x50000000|extra, x, y, w, h, builder, uintptr(id))
	send.Call(c, 0x30, font(-17), 1)
	return c
}
func label(text string, x, y, w, h int) { control("STATIC", text, x, y, w, h, 0, 0) }
func edit(id int, value string, x, y, w, h int, multi bool) {
	extra := uintptr(0x00010000 | 0x80)
	if multi {
		extra = 0x00010000 | 0x00200000 | 0x0004 | 0x0040 | 0x1000
	}
	value = strings.ReplaceAll(value, "\r\n", "\n")
	fields[id] = control("EDIT", strings.ReplaceAll(value, "\n", "\r\n"), x, y, w, h, id, extra)
	send.Call(fields[id], 0xD3, 3, 10|10<<16)
}
func startPlayer(c Config, isPreview bool) {
	cfg = c
	preview = isPreview
	stage = -1
	invalidPassword = false
	start = time.Now()
	w, _, _ := user.NewProc("GetSystemMetrics").Call(0)
	h, _, _ := user.NewProc("GetSystemMetrics").Call(1)
	player = makeWindow("VisualPlayer", "Visual Demo — визуальный симулятор", 0x82000000, 0, 0, int(w), int(h), 0, 0)
	if player == 0 {
		notify("Не удалось открыть окно показа")
		return
	}
	input = makeWindow("EDIT", "", 0x408100A0, 0, 0, 100, 32, player, 201)
	send.Call(input, 0x30, font(22), 1)
	exitButton = makeWindow("BUTTON", "Выйти / Exit", 0x50010000, int(w)-172, 20, 148, 34, player, 202)
	send.Call(exitButton, 0x30, font(17), 1)
	if builder != 0 {
		show.Call(builder, 0)
	}
	audioError = startMusic()
	start = time.Now()
	show.Call(player, 5)
	user.NewProc("SetTimer").Call(player, 1, 60, 0)
}
func beep() {
	if time.Since(lastBeep) < 180*time.Millisecond {
		return
	}
	lastBeep = time.Now()
	go kernel.NewProc("Beep").Call(880, 85)
}
func checkPassword() {
	if textOf(input) == cfg.Password {
		destroy.Call(player)
		return
	}
	invalidPassword = true
	setText.Call(input, uintptr(unsafe.Pointer(u(""))))
	beep()
	invalidate.Call(player, 0, 0)
}
func dimensions(h uintptr) (int, int) {
	var r rect
	user.NewProc("GetClientRect").Call(h, uintptr(unsafe.Pointer(&r)))
	return int(r.R), int(r.B)
}
func fill(dc uintptr, r rect, color uintptr) {
	brush, _, _ := gdi.NewProc("CreateSolidBrush").Call(color)
	user.NewProc("FillRect").Call(dc, uintptr(unsafe.Pointer(&r)), brush)
	gdi.NewProc("DeleteObject").Call(brush)
}
func drawText(dc uintptr, text string, r rect, size int, color uintptr, flags uintptr) {
	old, _, _ := gdi.NewProc("SelectObject").Call(dc, font(size))
	gdi.NewProc("SetTextColor").Call(dc, color)
	gdi.NewProc("SetBkMode").Call(dc, 1)
	user.NewProc("DrawTextW").Call(dc, uintptr(unsafe.Pointer(u(text))), ^uintptr(0), uintptr(unsafe.Pointer(&r)), flags|0x800)
	gdi.NewProc("SelectObject").Call(dc, old)
}
func outline(dc uintptr, r rect, color uintptr) {
	fill(dc, rect{r.L, r.T, r.R, r.T + 1}, color)
	fill(dc, rect{r.L, r.B - 1, r.R, r.B}, color)
	fill(dc, rect{r.L, r.T, r.L + 1, r.B}, color)
	fill(dc, rect{r.R - 1, r.T, r.R, r.B}, color)
}
func rr(x, y, w, h int) rect { return rect{int32(x), int32(y), int32(x + w), int32(y + h)} }
func redraw(h uintptr) {
	var ps paint
	real, _, _ := user.NewProc("BeginPaint").Call(h, uintptr(unsafe.Pointer(&ps)))
	defer user.NewProc("EndPaint").Call(h, uintptr(unsafe.Pointer(&ps)))
	w, height := dimensions(h)
	if w <= 0 || height <= 0 {
		return
	}
	dc, _, _ := gdi.NewProc("CreateCompatibleDC").Call(real)
	bitmap, _, _ := gdi.NewProc("CreateCompatibleBitmap").Call(real, uintptr(w), uintptr(height))
	old, _, _ := gdi.NewProc("SelectObject").Call(dc, bitmap)
	defer func() {
		gdi.NewProc("SelectObject").Call(dc, old)
		gdi.NewProc("DeleteObject").Call(bitmap)
		gdi.NewProc("DeleteDC").Call(dc)
	}()
	age := time.Since(start).Seconds()
	seconds := float64(cfg.Seconds)
	current := int(age / seconds)
	if current > 3 {
		current = 3
	}
	bg := rgb(0, 0, 0)
	if current == 2 {
		bg = rgb(145, 0, 0)
	}
	if current == 3 {
		bg = rgb(0, 0, 220)
	}
	fill(dc, rr(0, 0, w, height), bg)
	white := rgb(240, 240, 240)
	muted := rgb(170, 180, 195)
	red := rgb(255, 65, 65)
	if current != stage {
		stage = current
		if stage == 0 {
			beep()
		}
		if stage == 3 {
			panelW := min(760, w-48)
			x := (w - panelW) / 2
			y := max(84, (height-390)/2)
			user.NewProc("MoveWindow").Call(input, uintptr(x+24), uintptr(y+278), uintptr(panelW-48), 34, 1)
			show.Call(input, 5)
			fg, _, _ := user.NewProc("GetForegroundWindow").Call()
			if fg == h {
				user.NewProc("SetFocus").Call(input)
			}
			beep()
		}
	}
	switch current {
	case 0:
		eyeW := min(250, w/3)
		cy := height/2 - 50
		pen, _, _ := gdi.NewProc("CreatePen").Call(0, 3, white)
		prevPen, _, _ := gdi.NewProc("SelectObject").Call(dc, pen)
		stock, _, _ := gdi.NewProc("GetStockObject").Call(5)
		prevBrush, _, _ := gdi.NewProc("SelectObject").Call(dc, stock)
		gdi.NewProc("Ellipse").Call(dc, uintptr((w-eyeW)/2), uintptr(cy-42), uintptr((w+eyeW)/2), uintptr(cy+42))
		gdi.NewProc("Ellipse").Call(dc, uintptr(w/2-31), uintptr(cy-31), uintptr(w/2+31), uintptr(cy+31))
		fill(dc, rr(w/2-8, cy-8, 16, 16), white)
		gdi.NewProc("SelectObject").Call(dc, prevBrush)
		gdi.NewProc("SelectObject").Call(dc, prevPen)
		gdi.NewProc("DeleteObject").Call(pen)
		drawText(dc, cfg.Eye, rr(30, cy+70, w-60, 130), 38, white, 1|0x10)
	case 1:
		lines := strings.Split(strings.ReplaceAll(cfg.Errors, "\r\n", "\n"), "\n")
		count := min(len(lines), int((age-seconds)/seconds*float64(len(lines)))+1)
		drawText(dc, strings.Join(lines[:count], "\n"), rr(30, 35, w-60, height-160), 22, red, 0x10)
		drawText(dc, cfg.Eye, rr(30, height-170, w-60, 80), 30, white, 1|0x10)
	case 2:
		art := []string{
			"             .::::.             ",
			"           .::::::::.           ",
			"          :::      :::          ",
			"         :::  .::.  :::         ",
			"         ::: :::::: :::         ",
			"          :::  ::  :::          ",
			"        .:::::    :::::.        ",
			"      .::::::::  :::::::: .     ",
			"     ::::::::::  ::::::::::     ",
			"    :::::::::::  :::::::::::    ",
			"    :::::::::::  :::::::::::    ",
			"      :::::::::  :::::::::      ",
			"         ::::::  ::::::         ",
			"          ::::    ::::          ",
		}
		dy := int(math.Sin(age*3) * 4)
		drawText(dc, strings.Join(art, "\n"), rr(0, max(70, height/2-180)+dy, w, 420), 24, white, 1)
	case 3:
		pw := min(760, w-48)
		x := (w - pw) / 2
		y := max(84, (height-390)/2)
		outline(dc, rr(x, y, pw, 350), white)
		fill(dc, rr(x+16, y-13, pw-32, 28), white)
		drawText(dc, cfg.Title, rr(x+20, y-10, pw-40, 26), 19, rgb(0, 0, 150), 1)
		drawText(dc, cfg.Body, rr(x+22, y+35, pw-44, 203), 19, white, 0x10)
		drawText(dc, "Введите пароль для выхода:", rr(x+24, y+246, pw-48, 30), 20, white, 1)
		status := "Enter — подтвердить"
		if invalidPassword {
			status = "Неверный пароль. Попробуйте снова."
		}
		drawText(dc, status, rr(x+24, y+318, pw-48, 28), 17, white, 1)
		sceneAge := age - 3*seconds
		if sceneAge >= 2 && sceneAge < 5 {
			pr := rr(x+pw/2-210, y+65, 420, 130)
			fill(dc, pr, rgb(165, 0, 0))
			outline(dc, pr, white)
			drawText(dc, cfg.Popup, rr(int(pr.L)+15, int(pr.T)+22, 390, 100), 18, white, 1|0x10)
		}
	}
	footnote := "ВИЗУАЛЬНАЯ ДЕМОНСТРАЦИЯ  •  Esc: писк  •  Alt+F4: выход"
	if audioError != nil {
		footnote += "  •  Музыка недоступна"
	}
	drawText(dc, footnote, rr(24, height-46, w-48, 30), 15, muted, 0x10)
	gdi.NewProc("BitBlt").Call(real, 0, 0, uintptr(w), uintptr(height), dc, 0, 0, 0x00CC0020)
}

func builderProc(h uintptr, m uint32, w, l uintptr) uintptr {
	if result, handled := builderAppearance(h, m, w, l); handled {
		return result
	}
	switch m {
	case 0x111:
		if (w >> 16) == 0x300 {
			invalidate.Call(h, 0, 0)
			return 0
		}
		switch int(w & 0xffff) {
		case 100, 101:
			c, err := readConfig()
			if err != nil {
				notify(err.Error())
				return 0
			}
			if int(w&0xffff) == 100 {
				startPlayer(c, true)
				return 0
			}
			path := strings.TrimSpace(textOf(fields[8]))
			if !strings.EqualFold(filepath.Ext(path), ".exe") {
				notify("Имя файла должно оканчиваться на .exe")
				return 0
			}
			data, err := pack(appBytes, c)
			if err == nil {
				err = writeExport(path, data)
			}
			if err != nil {
				notify(err.Error())
			} else {
				notify("Готово! EXE сохранён:\n" + path + "\n\nПароль: " + c.Password)
			}
			return 0
		case 103:
			chooseExportPath(h)
			return 0
		case 102:
			destroy.Call(h)
			return 0
		}
	case 2:
		user.NewProc("PostQuitMessage").Call(0)
		return 0
	}
	r, _, _ := defproc.Call(h, uintptr(m), w, l)
	return r
}
func playerProc(h uintptr, m uint32, w, l uintptr) uintptr {
	switch m {
	case 0x14:
		return 1
	case 0x0F:
		redraw(h)
		return 0
	case 0x113:
		invalidate.Call(h, 0, 0)
		return 0
	case 0x111:
		if int(w&0xffff) == 202 {
			destroy.Call(h)
			return 0
		}
	case 2:
		stopMusic()
		user.NewProc("KillTimer").Call(h, 1)
		player = 0
		input = 0
		exitButton = 0
		if preview && builder != 0 {
			show.Call(builder, 5)
		} else {
			user.NewProc("PostQuitMessage").Call(0)
		}
		return 0
	}
	r, _, _ := defproc.Call(h, uintptr(m), w, l)
	return r
}
func main() {
	defer stopMusic()
	runtime.LockOSThread()
	user.NewProc("SetProcessDPIAware").Call()
	instance, _, _ = kernel.NewProc("GetModuleHandleW").Call(0)
	cursor, _, _ := user.NewProc("LoadCursorW").Call(0, 32512)
	for _, cls := range []struct {
		name string
		proc uintptr
	}{{"VisualBuilder", syscall.NewCallback(builderProc)}, {"VisualPlayer", syscall.NewCallback(playerProc)}} {
		c := wc{Size: uint32(unsafe.Sizeof(wc{})), Proc: cls.proc, Instance: instance, Cursor: cursor, Background: 16, Name: u(cls.name)}
		result, _, _ := user.NewProc("RegisterClassExW").Call(uintptr(unsafe.Pointer(&c)))
		if result == 0 {
			notify("Не удалось зарегистрировать окно")
			return
		}
	}
	exe, err := os.Executable()
	if err == nil {
		appBytes, err = os.ReadFile(exe)
	}
	if err != nil {
		notify(fmt.Sprint(err))
		return
	}
	_, embedded, err := unpack(appBytes)
	if err != nil {
		notify(err.Error())
		return
	}
	if embedded != nil {
		startPlayer(*embedded, false)
	} else {
		initBuilder()
	}
	var message msg
	for {
		r, _, _ := user.NewProc("GetMessageW").Call(uintptr(unsafe.Pointer(&message)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		// Only messages dispatched to this application's own window are handled.
		// No hooks, hotkey registration, task-manager changes, or close cancellation.
		if player != 0 && (message.H == player || message.H == input || message.H == exitButton) && message.M == 0x100 {
			if message.W == 0x1B {
				beep()
				continue
			}
			if message.W == 0x0D && message.H == exitButton {
				destroy.Call(player)
				continue
			}
			if message.W == 0x0D && stage == 3 {
				checkPassword()
				continue
			}
		}
		if message.M == 0x100 && message.W == 9 {
			target := builder
			if player != 0 {
				target = player
			}
			done, _, _ := user.NewProc("IsDialogMessageW").Call(target, uintptr(unsafe.Pointer(&message)))
			if done != 0 {
				continue
			}
		}
		user.NewProc("TranslateMessage").Call(uintptr(unsafe.Pointer(&message)))
		user.NewProc("DispatchMessageW").Call(uintptr(unsafe.Pointer(&message)))
	}
	for _, brush := range []uintptr{builderBrush, editBrush} {
		if brush != 0 {
			gdi.NewProc("DeleteObject").Call(brush)
		}
	}
	for _, f := range fonts {
		gdi.NewProc("DeleteObject").Call(f)
	}
}
