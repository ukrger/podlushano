//go:build windows

package main

import (
	_ "embed"
	"fmt"
	"os"
	"path/filepath"
	"syscall"
	"unsafe"
)

//go:embed track.mp3
var soundtrack []byte

var (
	winmm      = syscall.NewLazyDLL("winmm.dll")
	mci        = winmm.NewProc("mciSendStringW")
	audioDir   string
	audioOpen  bool
	audioError error
)

func musicCommand(command string) error {
	code, _, _ := mci.Call(uintptr(unsafe.Pointer(u(command))), 0, 0, 0)
	if code == 0 {
		return nil
	}
	var buffer [256]uint16
	winmm.NewProc("mciGetErrorStringW").Call(code, uintptr(unsafe.Pointer(&buffer[0])), uintptr(len(buffer)))
	return fmt.Errorf("звук: %s (код %d)", syscall.UTF16ToString(buffer[:]), code)
}

func startMusic() error {
	stopMusic()
	dir, err := os.MkdirTemp("", "visual-demo-audio-")
	if err != nil {
		return err
	}
	audioDir = dir
	path := filepath.Join(dir, "track.mp3")
	if err = os.WriteFile(path, soundtrack, 0600); err != nil {
		stopMusic()
		return err
	}
	if err = musicCommand(`open "` + path + `" type mpegvideo alias visual_demo_audio`); err != nil {
		stopMusic()
		return err
	}
	audioOpen = true
	if err = musicCommand("setaudio visual_demo_audio volume to 450"); err != nil {
		stopMusic()
		return err
	}
	if err = musicCommand("play visual_demo_audio repeat"); err != nil {
		stopMusic()
		return err
	}
	return nil
}

func stopMusic() {
	if audioOpen {
		musicCommand("close visual_demo_audio")
		audioOpen = false
	}
	if audioDir != "" {
		os.RemoveAll(audioDir)
		audioDir = ""
	}
}
