package main

import (
	"bytes"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"strings"
)

type Config struct {
	Eye      string `json:"eye"`
	Errors   string `json:"errors"`
	Title    string `json:"title"`
	Body     string `json:"body"`
	Popup    string `json:"popup"`
	Password string `json:"password"`
	Seconds  int    `json:"seconds_per_scene"`
}

func defaults() Config {
	return Config{
		Eye:      "ВАС ЗАМЕТИЛИ",
		Errors:   "Boot simulation started...\nDisplay check: OK\nMemory check: OK\nScene renderer: READY\nLoading visual interface...",
		Title:    "ДЕМОНСТРАЦИОННЫЙ ЭКРАН",
		Body:     "Это визуальная имитация из видеоролика.\nФайлы и настройки компьютера не изменяются.\n\nВведите демонстрационный пароль для завершения.\nEsc — короткий звуковой сигнал.",
		Popup:    "Замечена попытка покинуть сцену!\nЭто только визуальный эффект.",
		Password: "1234", Seconds: 3,
	}
}

func (c Config) validate() error {
	for _, s := range []string{c.Eye, c.Errors, c.Title, c.Body, c.Popup, c.Password} {
		if strings.ContainsRune(s, 0) || len(s) > 16000 {
			return errors.New("Текст слишком длинный или содержит нулевой символ")
		}
	}
	if c.Password == "" {
		return errors.New("Укажите пароль")
	}
	if c.Seconds < 1 || c.Seconds > 30 {
		return errors.New("Длительность сцены: от 1 до 30 секунд")
	}
	return nil
}

var marker = []byte("VISUAL_DEMO_CONFIG_V1_END!")

func unpack(data []byte) ([]byte, *Config, error) {
	if !bytes.HasSuffix(data, marker) {
		return data, nil, nil
	}
	end := len(data) - len(marker)
	if end < 8 {
		return nil, nil, errors.New("Повреждённый EXE: нет длины настроек")
	}
	n := binary.LittleEndian.Uint64(data[end-8 : end])
	if n > 1<<20 || n > uint64(end-8) {
		return nil, nil, errors.New("Повреждённая длина настроек")
	}
	start := end - 8 - int(n)
	var c Config
	if err := json.Unmarshal(data[start:end-8], &c); err != nil {
		return nil, nil, err
	}
	if err := c.validate(); err != nil {
		return nil, nil, err
	}
	return data[:start], &c, nil
}

func pack(data []byte, c Config) ([]byte, error) {
	if err := c.validate(); err != nil {
		return nil, err
	}
	base, _, err := unpack(data)
	if err != nil {
		return nil, err
	}
	payload, err := json.Marshal(c)
	if err != nil {
		return nil, err
	}
	out := append([]byte(nil), base...)
	out = append(out, payload...)
	var size [8]byte
	binary.LittleEndian.PutUint64(size[:], uint64(len(payload)))
	out = append(out, size[:]...)
	out = append(out, marker...)
	return out, nil
}

func writeExport(path string, data []byte) error {
	f, err := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0755)
	if err != nil {
		return fmt.Errorf("Не удалось создать EXE. Выберите новое имя файла.\n%w", err)
	}
	_, err = f.Write(data)
	closeErr := f.Close()
	if err != nil {
		os.Remove(path)
		return err
	}
	return closeErr
}
