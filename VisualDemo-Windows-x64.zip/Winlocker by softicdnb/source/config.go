package main

import (
	"bytes"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"strings"
)

type Config struct {
	Eye      string `json:"eye"`
	Errors   string `json:"errors"`
	Title    string `json:"title"`
	Body     string `json:"body"`
	Popup    string `json:"popup"`
	Password string `json:"password"`
	Seconds  int    `json:"seconds_per_scene"`
}

func defaults() Config {
	return Config{
		Eye:      "ВАС ЗАМЕТИЛИ",
		Errors:   "Booting Windows . . .\nBoot error: 0x03527737\nBoot error: 0x0266712\nBoot error: 0x02897593\nBoot error: 0x01447812\nBoot error: 0x0150974\nBoot error: 0x03873700\nBoot error: 0x0700882\nBoot error: 0x03803618\nMemory section at address 0x0424* is locked!\nService UXCryptor started.\n\n* Windows blocked!",
		Title:    "Ваши файлы зашифрованы!",
		Body:     "Упс! Вы подверглись масштабной хакерской атаке и теперь ваш компьютер\nзаблокирован, а все имеющиеся диски и файлы на них зашифрованы.\nЛюбые действия, связанные с попыткой обмануть систему,\nмогут привести к потере доступа ко всем важным файлам.\n\nДля восстановления доступа необходимо ввести код разблокировки.\nУ вас есть 48 часов с момента запуска, чтобы ввести код.\n\nВведите код в поле ниже и нажмите Enter.",
		Popup:    "Замечена и остановлена попытка\nобмануть систему!",
		Password: "1234", Seconds: 3,
	}
}

func (c Config) validate() error {
	for _, s := range []string{c.Eye, c.Errors, c.Title, c.Body, c.Popup, c.Password} {
		if strings.ContainsRune(s, 0) || len(s) > 16000 {
			return errors.New("Текст слишком длинный или содержит нулевой символ")
		}
	}
	if c.Password == "" {
		return errors.New("Укажите пароль")
	}
	if c.Seconds < 1 || c.Seconds > 30 {
		return errors.New("Длительность сцены: от 1 до 30 секунд")
	}
	return nil
}

var marker = []byte("VISUAL_DEMO_CONFIG_V1_END!")

func unpack(data []byte) ([]byte, *Config, error) {
	if !bytes.HasSuffix(data, marker) {
		return data, nil, nil
	}
	end := len(data) - len(marker)
	if end < 8 {
		return nil, nil, errors.New("Повреждённый EXE: нет длины настроек")
	}
	n := binary.LittleEndian.Uint64(data[end-8 : end])
	if n > 1<<20 || n > uint64(end-8) {
		return nil, nil, errors.New("Повреждённая длина настроек")
	}
	start := end - 8 - int(n)
	var c Config
	if err := json.Unmarshal(data[start:end-8], &c); err != nil {
		return nil, nil, err
	}
	if err := c.validate(); err != nil {
		return nil, nil, err
	}
	return data[:start], &c, nil
}

func pack(data []byte, c Config) ([]byte, error) {
	if err := c.validate(); err != nil {
		return nil, err
	}
	base, _, err := unpack(data)
	if err != nil {
		return nil, err
	}
	payload, err := json.Marshal(c)
	if err != nil {
		return nil, err
	}
	out := append([]byte(nil), base...)
	out = append(out, payload...)
	var size [8]byte
	binary.LittleEndian.PutUint64(size[:], uint64(len(payload)))
	out = append(out, size[:]...)
	out = append(out, marker...)
	return out, nil
}

func writeExport(path string, data []byte) error {
	f, err := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0755)
	if err != nil {
		return fmt.Errorf("Не удалось создать EXE. Выберите новое имя файла.\n%w", err)
	}
	_, err = f.Write(data)
	closeErr := f.Close()
	if err != nil {
		os.Remove(path)
		return err
	}
	return closeErr
}
