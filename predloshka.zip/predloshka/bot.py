"""
Анонимный Telegram-бот для личных сообщений (по типу AnonAskBot, но без канала).

Как это работает:
- У каждого пользователя есть персональная ссылка вида
  https://t.me/BOT_USERNAME?start=TELEGRAM_ID
- Любой, кто перейдёт по ссылке, может написать владельцу анонимно.
- Получатель видит только текст/медиа, но не автора.
- Администраторы (см. ADMIN_IDS в .env) видят обе стороны через /admin.

Запуск:
    py -m pip install -r requirements.txt
    py bot.py

Подробности — в README, который идёт вместе с этим файлом.
"""

import asyncio
import html as html_lib
import logging
import os
import secrets
import string
from datetime import datetime, timedelta

from dotenv import load_dotenv

from aiogram import Bot, Dispatcher, Router, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import Command, CommandStart, CommandObject, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    Message,
    CallbackQuery,
    ErrorEvent,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    ReplyKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardRemove,
)
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError, TelegramRetryAfter

from sqlalchemy import (
    BigInteger,
    String,
    Integer,
    Boolean,
    DateTime,
    ForeignKey,
    Text,
    select,
    func,
)
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


# ======================================================================================
# КОНФИГУРАЦИЯ
# ======================================================================================

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN")
if not BOT_TOKEN:
    raise RuntimeError(
        "BOT_TOKEN не задан. Скопируйте .env.example в .env и вставьте туда токен бота."
    )

ADMIN_IDS = {int(x.strip()) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip()}

DB_PATH = os.getenv("DB_PATH", "anon_bot.db")
DATABASE_URL = f"sqlite+aiosqlite:///{DB_PATH}"

PAGE_SIZE = 8
BROADCAST_DELAY = 0.05  # пауза между сообщениями рассылки, чтобы не словить FloodWait

ALLOWED_CONTENT = {
    "text",
    "photo",
    "video",
    "animation",
    "document",
    "audio",
    "voice",
    "video_note",
    "sticker",
}


# ======================================================================================
# ЛОГИРОВАНИЕ
# ======================================================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    handlers=[
        logging.FileHandler("bot.log", encoding="utf-8"),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger("anon_bot")


# ======================================================================================
# БАЗА ДАННЫХ (SQLAlchemy async + SQLite)
# ======================================================================================

class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    telegram_id: Mapped[int] = mapped_column(BigInteger, unique=True, index=True)
    username: Mapped[str | None] = mapped_column(String(64), nullable=True)
    first_name: Mapped[str | None] = mapped_column(String(128), nullable=True)
    link_code: Mapped[str | None] = mapped_column(String(16), unique=True, index=True, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    is_blocked: Mapped[bool] = mapped_column(Boolean, default=False)


class Message(Base):
    __tablename__ = "messages"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    sender_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    receiver_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    message_type: Mapped[str] = mapped_column(String(32))
    text: Mapped[str | None] = mapped_column(Text, nullable=True)
    file_id: Mapped[str | None] = mapped_column(String(256), nullable=True)
    caption: Mapped[str | None] = mapped_column(Text, nullable=True)
    sender_tg_message_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    receiver_tg_message_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    parent_message_id: Mapped[int | None] = mapped_column(ForeignKey("messages.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class Complaint(Base):
    __tablename__ = "complaints"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    message_id: Mapped[int] = mapped_column(ForeignKey("messages.id"))
    reporter_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    reason: Mapped[str] = mapped_column(String(64))
    status: Mapped[str] = mapped_column(String(16), default="open")  # open / closed
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


engine = create_async_engine(DATABASE_URL, echo=False)
SessionLocal = async_sessionmaker(engine, expire_on_commit=False)


async def init_db() -> None:
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

        def _get_columns(sync_conn):
            return [row[1] for row in sync_conn.exec_driver_sql("PRAGMA table_info(users)").fetchall()]

        columns = await conn.run_sync(_get_columns)
        if "link_code" not in columns:
            # Бот уже работал раньше на старой схеме без link_code — добавляем колонку,
            # ничего из существующих данных не теряется.
            await conn.exec_driver_sql("ALTER TABLE users ADD COLUMN link_code VARCHAR(16)")
            logger.info("Миграция БД: добавлена колонка link_code в таблицу users.")

    # Генерируем link_code всем, у кого его ещё нет (новые записи или те, что появились до миграции)
    async with SessionLocal() as session:
        result = await session.execute(select(User).where(User.link_code.is_(None)))
        users_without_code = result.scalars().all()
        for u in users_without_code:
            u.link_code = await generate_unique_link_code(session)
        if users_without_code:
            await session.commit()
            logger.info(f"Сгенерированы персональные ссылки для {len(users_without_code)} пользователей.")


_LINK_CODE_ALPHABET = string.ascii_lowercase + string.digits


def _random_link_code(length: int = 8) -> str:
    return "".join(secrets.choice(_LINK_CODE_ALPHABET) for _ in range(length))


async def generate_unique_link_code(session: AsyncSession) -> str:
    """Генерирует случайный непрозрачный код для персональной ссылки — по нему нельзя
    вычислить настоящий Telegram ID пользователя."""
    for _ in range(10):
        code = _random_link_code()
        exists = (await session.execute(select(User.id).where(User.link_code == code))).scalar_one_or_none()
        if not exists:
            return code
    return _random_link_code(length=12)  # почти невозможный случай коллизий подряд


async def get_or_create_user(session: AsyncSession, tg_user) -> User:
    """Находит пользователя по telegram_id или создаёт нового, обновляя username/имя."""
    result = await session.execute(select(User).where(User.telegram_id == tg_user.id))
    user = result.scalar_one_or_none()
    if user is None:
        user = User(
            telegram_id=tg_user.id,
            username=tg_user.username,
            first_name=tg_user.first_name,
            link_code=await generate_unique_link_code(session),
        )
        session.add(user)
        await session.commit()
        await session.refresh(user)
        return user

    changed = False
    if user.username != tg_user.username:
        user.username = tg_user.username
        changed = True
    if user.first_name != tg_user.first_name:
        user.first_name = tg_user.first_name
        changed = True
    if user.link_code is None:
        user.link_code = await generate_unique_link_code(session)
        changed = True
    if changed:
        await session.commit()
    return user


def extract_file_id(message: Message) -> str | None:
    """Достаёт file_id из сообщения, если это медиа. Файлы на диск не скачиваются."""
    if message.photo:
        return message.photo[-1].file_id
    if message.video:
        return message.video.file_id
    if message.animation:
        return message.animation.file_id
    if message.document:
        return message.document.file_id
    if message.audio:
        return message.audio.file_id
    if message.voice:
        return message.voice.file_id
    if message.video_note:
        return message.video_note.file_id
    if message.sticker:
        return message.sticker.file_id
    return None


def is_admin(telegram_id: int) -> bool:
    return telegram_id in ADMIN_IDS


# Типы контента, для которых Telegram позволяет задать подпись (caption) при копировании —
# для них плашку-заголовок и сам контент можно склеить в одно сообщение.
CAPTION_CAPABLE_TYPES = {"photo", "video", "animation", "document", "audio", "voice"}


async def deliver_content_with_header(
    bot: Bot,
    message: Message,
    target_chat_id: int,
    header: str,
    reply_markup: InlineKeyboardMarkup,
) -> Message:
    """Доставляет содержимое message получателю ОДНИМ сообщением вместе с заголовком-плашкой,
    где это позволяет Telegram API (текст, фото, видео, документы, аудио, голосовые).
    У стикеров и видеосообщений подписи не бывает в принципе — для них заголовок неизбежно
    уходит отдельным сообщением перед самим контентом.
    Возвращает доставленное сообщение (к нему прикреплены кнопки «Ответить»/«Пожаловаться»)."""
    if message.content_type == "text":
        safe_text = html_lib.escape(message.text)
        combined = f"<b>{header}</b>\n\n{safe_text}"
        return await bot.send_message(target_chat_id, combined, reply_markup=reply_markup)

    if message.content_type in CAPTION_CAPABLE_TYPES:
        safe_caption = html_lib.escape(message.caption) if message.caption else None
        caption = f"<b>{header}</b>\n\n{safe_caption}" if safe_caption else f"<b>{header}</b>"
        return await bot.copy_message(
            chat_id=target_chat_id,
            from_chat_id=message.chat.id,
            message_id=message.message_id,
            caption=caption[:1024],
            reply_markup=reply_markup,
        )

    # sticker / video_note — Telegram не поддерживает подписи для них
    await bot.send_message(target_chat_id, header)
    return await bot.copy_message(
        chat_id=target_chat_id,
        from_chat_id=message.chat.id,
        message_id=message.message_id,
        reply_markup=reply_markup,
    )


# ======================================================================================
# КЛАВИАТУРЫ
# ======================================================================================

def main_menu_kb() -> ReplyKeyboardMarkup:
    keyboard = [
        [KeyboardButton(text="🔗 Моя ссылка"), KeyboardButton(text="💌 Отправить сообщение")],
        [KeyboardButton(text="📩 Мои полученные сообщения")],
        [KeyboardButton(text="⚙️ Настройки"), KeyboardButton(text="ℹ️ Помощь")],
    ]
    return ReplyKeyboardMarkup(keyboard=keyboard, resize_keyboard=True)


def message_actions_kb(message_db_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="↩️ Ответить", callback_data=f"reply:{message_db_id}")],
            [InlineKeyboardButton(text="⚠️ Пожаловаться", callback_data=f"complain:{message_db_id}")],
        ]
    )


def admin_main_kb() -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text="👥 Пользователи", callback_data="adm_users:0")],
        [InlineKeyboardButton(text="💌 Сообщения", callback_data="adm_msgs:0")],
        [InlineKeyboardButton(text="📊 Статистика", callback_data="adm_stats")],
        [InlineKeyboardButton(text="📢 Рассылка", callback_data="adm_broadcast")],
        [InlineKeyboardButton(text="🔎 Поиск пользователя", callback_data="adm_search")],
        [InlineKeyboardButton(text="🚨 Жалобы", callback_data="adm_complaints:0")],
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


# ======================================================================================
# FSM СОСТОЯНИЯ
# ======================================================================================

class SendMessageStates(StatesGroup):
    waiting_for_target = State()
    waiting_for_content = State()


class ReplyStates(StatesGroup):
    waiting_for_reply = State()


class AdminStates(StatesGroup):
    waiting_for_broadcast = State()
    waiting_for_search = State()


# ======================================================================================
# ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ДЛЯ АДМИНКИ (переиспользуются в нескольких хендлерах)
# ======================================================================================

async def render_user_detail(bot: Bot, user_db_id: int, page: int):
    """Возвращает (текст, клавиатура) для карточки пользователя в админке."""
    async with SessionLocal() as session:
        user = await session.get(User, user_db_id)
        if not user:
            return None, None
        sent = (
            await session.execute(
                select(func.count()).select_from(Message).where(Message.sender_id == user.id)
            )
        ).scalar_one()
        received = (
            await session.execute(
                select(func.count()).select_from(Message).where(Message.receiver_id == user.id)
            )
        ).scalar_one()

    bot_info = await bot.get_me()
    link = f"https://t.me/{bot_info.username}?start={user.link_code}"

    text = (
        "👤 Пользователь\n\n"
        f"ID: <code>{user.telegram_id}</code>\n"
        f"Username: @{user.username or '—'}\n"
        f"Имя: {user.first_name or '—'}\n"
        f"Регистрация: {user.created_at:%d.%m.%Y %H:%M}\n"
        f"Отправлено сообщений: {sent}\n"
        f"Получено сообщений: {received}\n"
        f"Статус: {'🚫 Заблокирован' if user.is_blocked else '🟢 Активен'}\n\n"
        f"🔗 {link}"
    )

    block_button = (
        InlineKeyboardButton(text="✅ Разблокировать", callback_data=f"adm_unblock:{user.id}:{page}")
        if user.is_blocked
        else InlineKeyboardButton(text="🚫 Заблокировать", callback_data=f"adm_block:{user.id}:{page}")
    )
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [block_button],
            [InlineKeyboardButton(text="⬅️ К списку", callback_data=f"adm_users:{page}")],
        ]
    )
    return text, kb


async def notify_admins_new_message(
    bot: Bot, sender: User, receiver: User, db_message: Message, is_reply: bool
) -> None:
    """Шлёт всем администраторам живое уведомление о новом анонимном сообщении/ответе,
    сразу раскрывая обе стороны (в отличие от получателя, который видит анонима)."""
    if not ADMIN_IDS:
        return

    kind = "↩️ Новый ответ" if is_reply else "💌 Новое анонимное сообщение"
    body = db_message.text or db_message.caption or f"[{db_message.message_type}]"
    text = (
        f"{kind} (видно только администратору)\n\n"
        f"👤 Отправитель: @{sender.username or '—'} (ID <code>{sender.telegram_id}</code>)\n"
        f"🎯 Получатель: @{receiver.username or '—'} (ID <code>{receiver.telegram_id}</code>)\n"
        f"💬 Тип: {db_message.message_type}\n"
        f"📄 Содержимое: {body[:300]}\n\n"
        f"Сообщение #{db_message.id}"
    )
    for admin_id in ADMIN_IDS:
        try:
            await bot.send_message(admin_id, text)
        except Exception as e:
            logger.warning(f"Не удалось уведомить администратора {admin_id}: {e}")


async def format_message_admin(session: AsyncSession, m: Message) -> str:
    sender = await session.get(User, m.sender_id)
    receiver = await session.get(User, m.receiver_id)
    body = m.text or m.caption or f"[{m.message_type}]"
    return (
        f"💌 Сообщение #{m.id}\n\n"
        f"👤 Отправитель: @{sender.username or '—'} (ID {sender.telegram_id})\n"
        f"🎯 Получатель: @{receiver.username or '—'} (ID {receiver.telegram_id})\n"
        f"📅 {m.created_at:%d.%m.%Y %H:%M}\n"
        f"💬 Тип: {m.message_type}\n\n"
        f"{body}"
    )


# ======================================================================================
# РОУТЕР ДЛЯ ОБЫЧНЫХ ПОЛЬЗОВАТЕЛЕЙ
# ======================================================================================

router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message, command: CommandObject, state: FSMContext):
    await state.clear()

    async with SessionLocal() as session:
        user = await get_or_create_user(session, message.from_user)
        if user.is_blocked:
            await message.answer("🚫 Вы заблокированы и не можете пользоваться ботом.")
            return

        payload = command.args
        if payload:
            result = await session.execute(select(User).where(User.link_code == payload))
            target = result.scalar_one_or_none()
            if target is None or target.is_blocked:
                await message.answer("⚠️ Эта ссылка недействительна или пользователь заблокирован.")
                return
            if target.telegram_id != user.telegram_id:
                await state.update_data(target_db_id=target.id)
                await state.set_state(SendMessageStates.waiting_for_content)
                await message.answer(
                    "✉️ Напишите анонимное сообщение (текст, фото, видео, голосовое, стикер и т.д.).\n"
                    "Оно будет доставлено получателю без указания вашего имени.",
                    reply_markup=ReplyKeyboardRemove(),
                )
                return
            # payload указывает на ссылку самого пользователя — просто открываем меню ниже

    await message.answer(
        "👋 Добро пожаловать в бот анонимных сообщений!\n\n"
        "Здесь вы можете получать анонимные сообщения по своей персональной ссылке "
        "и отвечать на них, оставаясь анонимными для собеседника.",
        reply_markup=main_menu_kb(),
    )


@router.message(StateFilter(None), F.text == "🔗 Моя ссылка")
async def my_link(message: Message):
    async with SessionLocal() as session:
        user = await get_or_create_user(session, message.from_user)
        link_code = user.link_code

    bot_info = await message.bot.get_me()
    link = f"https://t.me/{bot_info.username}?start={link_code}"
    share_url = f"https://t.me/share/url?url={link}&text=Напиши%20мне%20анонимно!"
    kb = InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="📤 Поделиться", url=share_url)]]
    )
    await message.answer(
        f"🔗 Ваша персональная ссылка:\n\n<code>{link}</code>\n\n"
        "Отправьте её друзьям, чтобы получать анонимные сообщения.",
        reply_markup=kb,
    )


@router.message(StateFilter(None), F.text == "💌 Отправить сообщение")
async def send_message_prompt(message: Message, state: FSMContext):
    await message.answer(
        "Введите @username или Telegram ID получателя, которому хотите написать анонимно.\n"
        "Либо просто перейдите по персональной ссылке этого человека."
    )
    await state.set_state(SendMessageStates.waiting_for_target)


@router.message(SendMessageStates.waiting_for_target, F.text)
async def resolve_target(message: Message, state: FSMContext):
    query = message.text.strip().lstrip("@")
    async with SessionLocal() as session:
        if query.isdigit():
            result = await session.execute(select(User).where(User.telegram_id == int(query)))
        else:
            result = await session.execute(select(User).where(User.username == query))
        target = result.scalar_one_or_none()

        if not target or target.is_blocked:
            await message.answer(
                "❌ Пользователь не найден или заблокирован. Проверьте ID/username и попробуйте снова."
            )
            return

        sender = await get_or_create_user(session, message.from_user)
        if target.id == sender.id:
            await message.answer("Нельзя отправить сообщение самому себе 🙂")
            return

        await state.update_data(target_db_id=target.id)

    await state.set_state(SendMessageStates.waiting_for_content)
    await message.answer("✉️ Теперь отправьте текст, фото, видео, голосовое или другое сообщение.")


@router.message(SendMessageStates.waiting_for_target)
async def resolve_target_invalid(message: Message):
    await message.answer("Пожалуйста, введите текстом Telegram ID или @username получателя.")


@router.message(SendMessageStates.waiting_for_content)
async def deliver_anonymous_message(message: Message, state: FSMContext, bot: Bot):
    if message.content_type not in ALLOWED_CONTENT:
        await message.answer(
            "⚠️ Этот тип содержимого не поддерживается. Отправьте текст, фото, видео, "
            "голосовое, стикер и т.п."
        )
        return

    data = await state.get_data()
    target_db_id = data.get("target_db_id")
    await state.clear()

    if not target_db_id:
        await message.answer("⚠️ Сессия истекла, попробуйте снова через «💌 Отправить сообщение».")
        return

    async with SessionLocal() as session:
        sender = await get_or_create_user(session, message.from_user)
        if sender.is_blocked:
            await message.answer("🚫 Вы заблокированы.")
            return

        target = await session.get(User, target_db_id)
        if not target or target.is_blocked:
            await message.answer("❌ Получатель недоступен.")
            return

        db_message = Message(
            sender_id=sender.id,
            receiver_id=target.id,
            message_type=message.content_type,
            text=message.text if message.content_type == "text" else None,
            caption=message.caption,
            file_id=extract_file_id(message),
            sender_tg_message_id=message.message_id,
        )
        session.add(db_message)
        await session.commit()
        await session.refresh(db_message)

        try:
            copied = await deliver_content_with_header(
                bot,
                message,
                target.telegram_id,
                "💌 Вам пришло новое анонимное сообщение:",
                message_actions_kb(db_message.id),
            )
            db_message.receiver_tg_message_id = copied.message_id
            await session.commit()
        except TelegramForbiddenError:
            await message.answer("⚠️ Не удалось доставить сообщение: получатель заблокировал бота.")
            return
        except TelegramBadRequest as e:
            logger.error(f"Ошибка доставки сообщения: {e}")
            await message.answer("⚠️ Не удалось доставить сообщение. Попробуйте позже.")
            return

        await notify_admins_new_message(bot, sender, target, db_message, is_reply=False)

    await message.answer("✅ Сообщение отправлено анонимно!", reply_markup=main_menu_kb())


@router.callback_query(F.data.startswith("reply:"))
async def start_reply(callback: CallbackQuery, state: FSMContext):
    msg_db_id = int(callback.data.split(":")[1])
    async with SessionLocal() as session:
        original = await session.get(Message, msg_db_id)
        if not original:
            await callback.answer("Сообщение не найдено", show_alert=True)
            return
    await state.update_data(reply_to_message_id=msg_db_id)
    await state.set_state(ReplyStates.waiting_for_reply)
    await callback.message.answer("✉️ Напишите ваш ответ (он будет отправлен анонимно).")
    await callback.answer()


@router.message(ReplyStates.waiting_for_reply)
async def deliver_reply(message: Message, state: FSMContext, bot: Bot):
    if message.content_type not in ALLOWED_CONTENT:
        await message.answer("⚠️ Неподдерживаемый тип сообщения.")
        return

    data = await state.get_data()
    original_id = data.get("reply_to_message_id")
    await state.clear()

    if not original_id:
        await message.answer("⚠️ Сессия истекла.")
        return

    async with SessionLocal() as session:
        original = await session.get(Message, original_id)
        if not original:
            await message.answer("⚠️ Исходное сообщение не найдено.")
            return

        replier = await get_or_create_user(session, message.from_user)
        if replier.is_blocked:
            await message.answer("🚫 Вы заблокированы.")
            return

        recipient = await session.get(User, original.sender_id)
        if not recipient or recipient.is_blocked:
            await message.answer("❌ Получатель недоступен.")
            return

        db_message = Message(
            sender_id=replier.id,
            receiver_id=recipient.id,
            message_type=message.content_type,
            text=message.text if message.content_type == "text" else None,
            caption=message.caption,
            file_id=extract_file_id(message),
            sender_tg_message_id=message.message_id,
            parent_message_id=original.id,
        )
        session.add(db_message)
        await session.commit()
        await session.refresh(db_message)

        try:
            copied = await deliver_content_with_header(
                bot,
                message,
                recipient.telegram_id,
                "↩️ Вам пришёл ответ на анонимное сообщение:",
                message_actions_kb(db_message.id),
            )
            db_message.receiver_tg_message_id = copied.message_id
            await session.commit()
        except TelegramForbiddenError:
            await message.answer("⚠️ Получатель заблокировал бота.")
            return
        except TelegramBadRequest as e:
            logger.error(f"Ошибка доставки ответа: {e}")
            await message.answer("⚠️ Не удалось доставить ответ.")
            return

        await notify_admins_new_message(bot, replier, recipient, db_message, is_reply=True)

    await message.answer("✅ Ответ отправлен анонимно!", reply_markup=main_menu_kb())


@router.callback_query(F.data.startswith("complain:"))
async def complain_start(callback: CallbackQuery):
    msg_db_id = int(callback.data.split(":")[1])
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🚫 Спам", callback_data=f"complain_reason:{msg_db_id}:spam")],
            [InlineKeyboardButton(text="🤬 Оскорбления", callback_data=f"complain_reason:{msg_db_id}:abuse")],
            [InlineKeyboardButton(text="🔞 Неприемлемый контент", callback_data=f"complain_reason:{msg_db_id}:inappropriate")],
            [InlineKeyboardButton(text="Другое", callback_data=f"complain_reason:{msg_db_id}:other")],
        ]
    )
    await callback.message.answer("Укажите причину жалобы:", reply_markup=kb)
    await callback.answer()


@router.callback_query(F.data.startswith("complain_reason:"))
async def complain_reason(callback: CallbackQuery):
    _, msg_db_id, reason = callback.data.split(":")
    async with SessionLocal() as session:
        reporter = await get_or_create_user(session, callback.from_user)
        complaint = Complaint(message_id=int(msg_db_id), reporter_id=reporter.id, reason=reason)
        session.add(complaint)
        await session.commit()
        await session.refresh(complaint)

        m = await session.get(Message, int(msg_db_id))
        author = await session.get(User, m.sender_id) if m else None

    for admin_id in ADMIN_IDS:
        try:
            await callback.bot.send_message(
                admin_id,
                "🚨 Новая жалоба\n\n"
                f"Причина: {reason}\n"
                f"На сообщение #{msg_db_id}\n"
                f"Автор сообщения: ID <code>{author.telegram_id if author else '—'}</code> "
                f"(@{author.username if author else '—'})\n\n"
                f"Открыть: /admin → 🚨 Жалобы",
            )
        except Exception as e:
            logger.warning(f"Не удалось уведомить администратора {admin_id} о жалобе: {e}")

    await callback.message.edit_text("✅ Жалоба отправлена администраторам.")
    await callback.answer()


async def _received_page(session: AsyncSession, user: User, page: int):
    offset = page * PAGE_SIZE
    total = (
        await session.execute(
            select(func.count()).select_from(Message).where(Message.receiver_id == user.id)
        )
    ).scalar_one()
    result = await session.execute(
        select(Message)
        .where(Message.receiver_id == user.id)
        .order_by(Message.created_at.desc())
        .offset(offset)
        .limit(PAGE_SIZE)
    )
    return result.scalars().all(), total


def _received_text(items, total: int) -> str:
    lines = [f"📩 Всего сообщений: {total}\n"]
    for m in items:
        lines.append(f"#{m.id} • {m.message_type} • {m.created_at:%d.%m.%Y %H:%M}")
    return "\n".join(lines)


@router.message(StateFilter(None), F.text == "📩 Мои полученные сообщения")
async def received_messages(message: Message):
    async with SessionLocal() as session:
        user = await get_or_create_user(session, message.from_user)
        items, total = await _received_page(session, user, 0)

    if not items:
        await message.answer("📭 У вас пока нет полученных сообщений.")
        return

    kb_rows = []
    if total > PAGE_SIZE:
        kb_rows.append([InlineKeyboardButton(text="След. страница ➡️", callback_data="recv_page:1")])
    kb = InlineKeyboardMarkup(inline_keyboard=kb_rows) if kb_rows else None
    await message.answer(_received_text(items, total), reply_markup=kb)


@router.callback_query(F.data.startswith("recv_page:"))
async def received_messages_page(callback: CallbackQuery):
    page = int(callback.data.split(":")[1])
    async with SessionLocal() as session:
        user = await get_or_create_user(session, callback.from_user)
        items, total = await _received_page(session, user, page)

    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️ Пред.", callback_data=f"recv_page:{page-1}"))
    if (page + 1) * PAGE_SIZE < total:
        nav.append(InlineKeyboardButton(text="След. ➡️", callback_data=f"recv_page:{page+1}"))
    kb = InlineKeyboardMarkup(inline_keyboard=[nav]) if nav else None
    await callback.message.edit_text(_received_text(items, total), reply_markup=kb)
    await callback.answer()


@router.message(StateFilter(None), F.text == "⚙️ Настройки")
async def settings_menu(message: Message):
    await message.answer("⚙️ Настройки пока в разработке. Здесь появятся уведомления и приватность.")


@router.message(StateFilter(None), F.text == "ℹ️ Помощь")
async def help_menu(message: Message):
    await message.answer(
        "ℹ️ Как это работает:\n\n"
        "1. Нажмите «🔗 Моя ссылка» и поделитесь ей с друзьями.\n"
        "2. Люди, перешедшие по ссылке, смогут написать вам анонимно.\n"
        "3. Вы получите сообщение без указания автора и сможете ответить.\n"
        "4. Если сообщение неприемлемо — нажмите «⚠️ Пожаловаться»."
    )


# ======================================================================================
# РОУТЕР ДЛЯ АДМИН-ПАНЕЛИ
# ======================================================================================

admin_router = Router()


@admin_router.message(Command("admin"))
async def admin_panel(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer("⛔ У вас нет доступа к этой команде.")
        return
    await message.answer("🛠 Админ-панель", reply_markup=admin_main_kb())


@admin_router.callback_query(F.data == "adm_back")
async def adm_back(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return await callback.answer("⛔ Доступ запрещён", show_alert=True)
    await callback.message.edit_text("🛠 Админ-панель", reply_markup=admin_main_kb())
    await callback.answer()


@admin_router.callback_query(F.data.startswith("adm_users:"))
async def adm_users(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return await callback.answer("⛔", show_alert=True)

    page = int(callback.data.split(":")[1])
    async with SessionLocal() as session:
        total = (await session.execute(select(func.count()).select_from(User))).scalar_one()
        result = await session.execute(
            select(User).order_by(User.created_at.desc()).offset(page * PAGE_SIZE).limit(PAGE_SIZE)
        )
        users = result.scalars().all()

    rows = []
    for u in users:
        label = f"{'🚫 ' if u.is_blocked else ''}{u.first_name or 'Без имени'} (@{u.username or '—'})"
        rows.append([InlineKeyboardButton(text=label, callback_data=f"adm_user:{u.id}:{page}")])

    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️", callback_data=f"adm_users:{page-1}"))
    if (page + 1) * PAGE_SIZE < total:
        nav.append(InlineKeyboardButton(text="➡️", callback_data=f"adm_users:{page+1}"))
    if nav:
        rows.append(nav)
    rows.append([InlineKeyboardButton(text="⬅️ Назад", callback_data="adm_back")])

    await callback.message.edit_text(
        f"👥 Пользователи (всего {total})", reply_markup=InlineKeyboardMarkup(inline_keyboard=rows)
    )
    await callback.answer()


@admin_router.callback_query(F.data.startswith("adm_user:"))
async def adm_user_detail(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return await callback.answer("⛔", show_alert=True)

    _, user_db_id, page = callback.data.split(":")
    text, kb = await render_user_detail(callback.bot, int(user_db_id), int(page))
    if text is None:
        return await callback.answer("Пользователь не найден", show_alert=True)
    await callback.message.edit_text(text, reply_markup=kb)
    await callback.answer()


@admin_router.callback_query(F.data.startswith("adm_block:"))
async def adm_block(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return await callback.answer("⛔", show_alert=True)

    _, user_db_id, page = callback.data.split(":")
    async with SessionLocal() as session:
        user = await session.get(User, int(user_db_id))
        if user:
            user.is_blocked = True
            await session.commit()

    kb = InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="⬅️ К списку", callback_data=f"adm_users:{page}")]]
    )
    await callback.message.edit_text("🚫 Пользователь заблокирован.", reply_markup=kb)
    await callback.answer()


@admin_router.callback_query(F.data.startswith("adm_unblock:"))
async def adm_unblock(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return await callback.answer("⛔", show_alert=True)

    _, user_db_id, page = callback.data.split(":")
    async with SessionLocal() as session:
        user = await session.get(User, int(user_db_id))
        if user:
            user.is_blocked = False
            await session.commit()

    kb = InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="⬅️ К списку", callback_data=f"adm_users:{page}")]]
    )
    await callback.message.edit_text("✅ Пользователь разблокирован.", reply_markup=kb)
    await callback.answer()


@admin_router.callback_query(F.data.startswith("adm_msgs:"))
async def adm_messages(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return await callback.answer("⛔", show_alert=True)

    page = int(callback.data.split(":")[1])
    async with SessionLocal() as session:
        total = (await session.execute(select(func.count()).select_from(Message))).scalar_one()
        result = await session.execute(
            select(Message).order_by(Message.created_at.desc()).offset(page * PAGE_SIZE).limit(PAGE_SIZE)
        )
        msgs = result.scalars().all()
        texts = [await format_message_admin(session, m) for m in msgs]

    text = f"💌 Сообщения (всего {total})\n\n" + "\n\n---\n\n".join(texts) if texts else "Сообщений нет."

    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️", callback_data=f"adm_msgs:{page-1}"))
    if (page + 1) * PAGE_SIZE < total:
        nav.append(InlineKeyboardButton(text="➡️", callback_data=f"adm_msgs:{page+1}"))
    rows = [nav] if nav else []
    rows.append([InlineKeyboardButton(text="⬅️ Назад", callback_data="adm_back")])

    await callback.message.edit_text(text[:4000], reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    await callback.answer()


@admin_router.callback_query(F.data == "adm_stats")
async def adm_stats(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return await callback.answer("⛔", show_alert=True)

    now = datetime.utcnow()
    async with SessionLocal() as session:
        total_users = (await session.execute(select(func.count()).select_from(User))).scalar_one()
        active_users = (
            await session.execute(select(func.count()).select_from(User).where(User.is_blocked.is_(False)))
        ).scalar_one()
        blocked_users = total_users - active_users
        total_messages = (await session.execute(select(func.count()).select_from(Message))).scalar_one()
        media_messages = (
            await session.execute(
                select(func.count()).select_from(Message).where(Message.message_type != "text")
            )
        ).scalar_one()
        total_complaints = (await session.execute(select(func.count()).select_from(Complaint))).scalar_one()
        today = (
            await session.execute(
                select(func.count()).select_from(User).where(User.created_at >= now - timedelta(days=1))
            )
        ).scalar_one()
        week = (
            await session.execute(
                select(func.count()).select_from(User).where(User.created_at >= now - timedelta(days=7))
            )
        ).scalar_one()
        month = (
            await session.execute(
                select(func.count()).select_from(User).where(User.created_at >= now - timedelta(days=30))
            )
        ).scalar_one()

    text = (
        "📊 Статистика\n\n"
        f"👥 Всего пользователей: {total_users}\n"
        f"🟢 Активных: {active_users}\n"
        f"🚫 Заблокированных: {blocked_users}\n"
        f"💌 Всего сообщений: {total_messages}\n"
        f"📸 Медиа-сообщений: {media_messages}\n"
        f"🚨 Жалоб: {total_complaints}\n"
        f"📈 Новых за сегодня: {today}\n"
        f"📈 Новых за неделю: {week}\n"
        f"📈 Новых за месяц: {month}\n"
    )
    kb = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="⬅️ Назад", callback_data="adm_back")]])
    await callback.message.edit_text(text, reply_markup=kb)
    await callback.answer()


@admin_router.callback_query(F.data == "adm_search")
async def adm_search_start(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return await callback.answer("⛔", show_alert=True)
    await callback.message.answer("🔎 Введите Telegram ID или @username пользователя:")
    await state.set_state(AdminStates.waiting_for_search)
    await callback.answer()


@admin_router.message(AdminStates.waiting_for_search)
async def adm_search_result(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    await state.clear()

    query = message.text.strip().lstrip("@")
    async with SessionLocal() as session:
        if query.isdigit():
            result = await session.execute(select(User).where(User.telegram_id == int(query)))
        else:
            result = await session.execute(select(User).where(User.username == query))
        user = result.scalar_one_or_none()

    if not user:
        await message.answer("Пользователь не найден.")
        return

    text, kb = await render_user_detail(message.bot, user.id, 0)
    await message.answer(text, reply_markup=kb)


@admin_router.callback_query(F.data == "adm_broadcast")
async def adm_broadcast_start(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return await callback.answer("⛔", show_alert=True)
    await callback.message.answer(
        "📢 Отправьте сообщение (текст, фото, видео или документ), которое нужно разослать всем пользователям."
    )
    await state.set_state(AdminStates.waiting_for_broadcast)
    await callback.answer()


@admin_router.message(AdminStates.waiting_for_broadcast)
async def adm_broadcast_preview(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return

    await state.update_data(broadcast_chat_id=message.chat.id, broadcast_message_id=message.message_id)
    async with SessionLocal() as session:
        total = (
            await session.execute(select(func.count()).select_from(User).where(User.is_blocked.is_(False)))
        ).scalar_one()

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="✅ Отправить", callback_data="adm_bc_confirm")],
            [InlineKeyboardButton(text="❌ Отмена", callback_data="adm_bc_cancel")],
        ]
    )
    await message.answer(
        f"📢 Вы собираетесь отправить сообщение {total} пользователям.\n\nПродолжить?", reply_markup=kb
    )


@admin_router.callback_query(F.data == "adm_bc_cancel")
async def adm_broadcast_cancel(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return await callback.answer("⛔", show_alert=True)
    await state.clear()
    await callback.message.edit_text("❌ Рассылка отменена.")
    await callback.answer()


@admin_router.callback_query(F.data == "adm_bc_confirm")
async def adm_broadcast_confirm(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return await callback.answer("⛔", show_alert=True)

    data = await state.get_data()
    await state.clear()
    src_chat = data.get("broadcast_chat_id")
    src_msg = data.get("broadcast_message_id")
    if not src_chat or not src_msg:
        await callback.answer("Сессия истекла", show_alert=True)
        return

    await callback.message.edit_text("⏳ Рассылка запущена...")

    async with SessionLocal() as session:
        result = await session.execute(select(User.telegram_id).where(User.is_blocked.is_(False)))
        targets = [row[0] for row in result.all()]

    sent, failed = 0, 0
    for tg_id in targets:
        try:
            await callback.bot.copy_message(chat_id=tg_id, from_chat_id=src_chat, message_id=src_msg)
            sent += 1
        except TelegramRetryAfter as e:
            await asyncio.sleep(e.retry_after)
            try:
                await callback.bot.copy_message(chat_id=tg_id, from_chat_id=src_chat, message_id=src_msg)
                sent += 1
            except Exception as e2:
                logger.warning(f"Рассылка не удалась для {tg_id}: {e2}")
                failed += 1
        except (TelegramForbiddenError, TelegramBadRequest) as e:
            logger.warning(f"Рассылка не удалась для {tg_id}: {e}")
            failed += 1
        await asyncio.sleep(BROADCAST_DELAY)

    await callback.message.answer(f"✅ Рассылка завершена.\nДоставлено: {sent}\nОшибок: {failed}")
    await callback.answer()


@admin_router.callback_query(F.data.startswith("adm_complaints:"))
async def adm_complaints(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return await callback.answer("⛔", show_alert=True)

    page = int(callback.data.split(":")[1])
    async with SessionLocal() as session:
        total = (
            await session.execute(
                select(func.count()).select_from(Complaint).where(Complaint.status == "open")
            )
        ).scalar_one()
        result = await session.execute(
            select(Complaint)
            .where(Complaint.status == "open")
            .order_by(Complaint.created_at.desc())
            .offset(page * PAGE_SIZE)
            .limit(PAGE_SIZE)
        )
        complaints = result.scalars().all()

    rows = [
        [InlineKeyboardButton(text=f"Жалоба #{c.id} ({c.reason})", callback_data=f"adm_complaint:{c.id}:{page}")]
        for c in complaints
    ]
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️", callback_data=f"adm_complaints:{page-1}"))
    if (page + 1) * PAGE_SIZE < total:
        nav.append(InlineKeyboardButton(text="➡️", callback_data=f"adm_complaints:{page+1}"))
    if nav:
        rows.append(nav)
    rows.append([InlineKeyboardButton(text="⬅️ Назад", callback_data="adm_back")])

    text = f"🚨 Открытые жалобы (всего {total})" if complaints else "🚨 Открытых жалоб нет."
    await callback.message.edit_text(text, reply_markup=InlineKeyboardMarkup(inline_keyboard=rows))
    await callback.answer()


@admin_router.callback_query(F.data.startswith("adm_complaint:"))
async def adm_complaint_detail(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return await callback.answer("⛔", show_alert=True)

    _, c_id, page = callback.data.split(":")
    async with SessionLocal() as session:
        complaint = await session.get(Complaint, int(c_id))
        if not complaint:
            return await callback.answer("Не найдена", show_alert=True)
        m = await session.get(Message, complaint.message_id)
        author = await session.get(User, m.sender_id) if m else None
        target = await session.get(User, m.receiver_id) if m else None
        reporter = await session.get(User, complaint.reporter_id)

    text = (
        f"🚨 Жалоба #{complaint.id}\n\n"
        f"Причина: {complaint.reason}\n"
        f"Автор жалобы: ID {reporter.telegram_id if reporter else '—'}\n\n"
        f"Сообщение #{m.id if m else '—'}\n"
        f"Отправитель: ID {author.telegram_id if author else '—'} (@{author.username if author else '—'})\n"
        f"Получатель: ID {target.telegram_id if target else '—'} (@{target.username if target else '—'})\n"
        f"Текст/тип: {(m.text or m.caption or m.message_type) if m else '—'}\n"
    )
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🚫 Заблокировать автора", callback_data=f"adm_complaint_block:{complaint.id}:{page}")],
            [InlineKeyboardButton(text="✅ Закрыть жалобу", callback_data=f"adm_complaint_close:{complaint.id}:{page}")],
            [InlineKeyboardButton(text="⬅️ Назад", callback_data=f"adm_complaints:{page}")],
        ]
    )
    await callback.message.edit_text(text, reply_markup=kb)
    await callback.answer()


@admin_router.callback_query(F.data.startswith("adm_complaint_block:"))
async def adm_complaint_block(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return await callback.answer("⛔", show_alert=True)

    _, c_id, page = callback.data.split(":")
    async with SessionLocal() as session:
        complaint = await session.get(Complaint, int(c_id))
        if complaint:
            m = await session.get(Message, complaint.message_id)
            if m:
                author = await session.get(User, m.sender_id)
                if author:
                    author.is_blocked = True
            complaint.status = "closed"
            await session.commit()

    kb = InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="⬅️ К жалобам", callback_data=f"adm_complaints:{page}")]]
    )
    await callback.message.edit_text("🚫 Автор заблокирован, жалоба закрыта.", reply_markup=kb)
    await callback.answer()


@admin_router.callback_query(F.data.startswith("adm_complaint_close:"))
async def adm_complaint_close(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return await callback.answer("⛔", show_alert=True)

    _, c_id, page = callback.data.split(":")
    async with SessionLocal() as session:
        complaint = await session.get(Complaint, int(c_id))
        if complaint:
            complaint.status = "closed"
            await session.commit()

    kb = InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="⬅️ К жалобам", callback_data=f"adm_complaints:{page}")]]
    )
    await callback.message.edit_text("✅ Жалоба закрыта.", reply_markup=kb)
    await callback.answer()


# ======================================================================================
# ЗАПУСК БОТА
# ======================================================================================

async def on_startup(bot: Bot) -> None:
    await init_db()
    logger.info("База данных инициализирована: %s", DB_PATH)
    if not ADMIN_IDS:
        logger.warning("ADMIN_IDS пуст — админ-панель будет недоступна никому!")


async def error_handler(event: ErrorEvent) -> bool:
    logger.exception("Ошибка при обработке апдейта %s: %s", event.update, event.exception)
    return True


async def main() -> None:
    bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher(storage=MemoryStorage())

    dp.error.register(error_handler)
    dp.startup.register(on_startup)

    dp.include_router(admin_router)
    dp.include_router(router)

    logger.info("Бот запускается...")
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logger.info("Бот остановлен.")
