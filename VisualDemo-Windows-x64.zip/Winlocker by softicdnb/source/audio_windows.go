//go:build windows

package main

import (
	_ "embed"
	"syscall"
	"unsafe"
)

//go:embed beep.wav
var beepSound []byte

var winmm = syscall.NewLazyDLL("winmm.dll")

func playBeep() {
	// The globally embedded buffer remains alive during asynchronous playback.
	winmm.NewProc("PlaySoundW").Call(uintptr(unsafe.Pointer(&beepSound[0])), 0, 0x7)
}

func stopBeep() { winmm.NewProc("PlaySoundW").Call(0, 0, 0) }
