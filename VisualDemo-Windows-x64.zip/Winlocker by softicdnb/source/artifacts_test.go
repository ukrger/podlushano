package main

import "testing"

func TestArtifactFramesKeepPasswordEntryClear(t *testing.T) {
	for frame := uint64(0); frame < 2000; frame++ {
		ops := gpuArtifacts(frame)
		if len(ops) < 50 {
			t.Fatalf("frame %d unexpectedly empty", frame)
		}
		for _, op := range ops {
			if op.X < 67 || op.Y < 207 || op.W < 1 || op.H < 1 || op.X+op.W > 1217 || op.Y+op.H > 540 {
				t.Fatalf("frame %d: patch outside the scene: %+v", frame, op)
			}
			if op.X < 1016 && op.X+op.W > 267 && op.Y < 468 && op.Y+op.H > 444 {
				t.Fatalf("frame %d: patch covers password entry: %+v", frame, op)
			}
			if op.Copy && (op.X+op.Shift < 67 || op.X+op.W+op.Shift > 1217) {
				t.Fatalf("frame %d: source outside scene: %+v", frame, op)
			}
		}
	}
}
