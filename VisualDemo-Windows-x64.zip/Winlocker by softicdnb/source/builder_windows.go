//go:build windows

package main

import (
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"
	"time"
	"unicode/utf16"
	"unsafe"
)

var (
	background              = rgb(11, 15, 24)
	surface                 = rgb(17, 23, 35)
	editor                  = rgb(25, 33, 48)
	ink                     = rgb(233, 239, 248)
	soft                    = rgb(145, 160, 181)
	accent                  = rgb(108, 229, 197)
	border                  = rgb(45, 56, 76)
	builderBrush, editBrush uintptr
	comdlg                  = syscall.NewLazyDLL("comdlg32.dll")
)

func utf16s(s string) []uint16 { return append(utf16.Encode([]rune(s)), 0) }
func syscallDLL(dll, proc string) *syscall.LazyProc {
	p := syscall.NewLazyDLL(dll).NewProc(proc)
	if p.Find() != nil {
		return nil
	}
	return p
}

type drawItem struct {
	Type, ID, ItemID, Action, State uint32
	Window, DC                      uintptr
	R                               rect
	Data                            uintptr
}

type saveFile struct {
	Size                      uint32
	Owner, Instance           uintptr
	Filter, CustomFilter      *uint16
	MaxCustom, FilterIndex    uint32
	File                      *uint16
	MaxFile                   uint32
	FileTitle                 *uint16
	MaxFileTitle              uint32
	InitialDir, Title         *uint16
	Flags                     uint32
	FileOffset, FileExtension uint16
	DefaultExt                *uint16
	Data                      uintptr
	Hook                      uintptr
	Template                  *uint16
	Reserved                  uintptr
	ReservedWord, FlagsEx     uint32
}

func readConfig() (Config, error) {
	c := cfg
	c.Title = textOf(fields[3])
	c.Body = textOf(fields[4])
	c.Password = textOf(fields[6])
	c.Seconds, _ = strconv.Atoi(strings.TrimSpace(textOf(fields[7])))
	return c, c.validate()
}

func initBuilder() {
	builderBrush, _, _ = gdi.NewProc("CreateSolidBrush").Call(background)
	editBrush, _, _ = gdi.NewProc("CreateSolidBrush").Call(editor)
	style := uintptr(0x02CA0000)
	r := rr(0, 0, 1000, 640)
	user.NewProc("AdjustWindowRect").Call(uintptr(unsafe.Pointer(&r)), style, 0)
	width, height := int(r.R-r.L), int(r.B-r.T)
	var work rect
	user.NewProc("SystemParametersInfoW").Call(48, 0, uintptr(unsafe.Pointer(&work)), 0)
	x := max(0, int(work.L)+(int(work.R-work.L)-width)/2)
	y := max(0, int(work.T)+(int(work.B-work.T)-height)/2)
	builder = makeWindow("VisualBuilder", "winlocker by softicdnb", style, x, y, width, height, 0, 0)
	// Ask DWM for a dark title bar where the Windows version supports it.
	dark := int32(1)
	dwm := syscallDLL("dwmapi.dll", "DwmSetWindowAttribute")
	if dwm != nil {
		dwm.Call(builder, 20, uintptr(unsafe.Pointer(&dark)), 4)
	}
	edit(3, cfg.Title, 42, 146, 548, 30, false)
	edit(4, cfg.Body, 42, 218, 548, 140, true)
	edit(6, cfg.Password, 42, 406, 322, 32, false)
	edit(7, strconv.Itoa(cfg.Seconds), 394, 406, 196, 32, false)
	exe, _ := os.Executable()
	edit(8, filepath.Join(filepath.Dir(exe), "MyWinlocker.exe"), 42, 482, 498, 32, false)
	control("BUTTON", "…", 548, 482, 42, 32, 103, 0xB)
	control("BUTTON", "Собрать EXE  →", 34, 548, 336, 44, 101, 0xB)
	control("BUTTON", "Предпросмотр", 390, 548, 208, 44, 100, 0xB)
	show.Call(builder, 5)
	user.NewProc("SetTimer").Call(builder, 2, 300, 0)
}

func chooseExportPath(h uintptr) {
	var name [32768]uint16
	current := textOf(fields[8])
	copy(name[:], utf16s(current))
	filter := utf16s("Windows EXE (*.exe)\x00*.exe\x00\x00")
	dialog := saveFile{
		Size: uint32(unsafe.Sizeof(saveFile{})), Owner: h,
		Filter: &filter[0], FilterIndex: 1, File: &name[0], MaxFile: uint32(len(name)),
		Title: u("Куда сохранить демонстрацию"), DefaultExt: u("exe"),
		Flags: 0x800 | 0x80000 | 0x8,
	}
	result, _, _ := comdlg.NewProc("GetSaveFileNameW").Call(uintptr(unsafe.Pointer(&dialog)))
	if result != 0 {
		setText.Call(fields[8], uintptr(unsafe.Pointer(&name[0])))
	}
}

func rounded(dc uintptr, r rect, color uintptr, radius int) {
	brush, _, _ := gdi.NewProc("CreateSolidBrush").Call(color)
	oldBrush, _, _ := gdi.NewProc("SelectObject").Call(dc, brush)
	nullPen, _, _ := gdi.NewProc("GetStockObject").Call(8)
	oldPen, _, _ := gdi.NewProc("SelectObject").Call(dc, nullPen)
	gdi.NewProc("RoundRect").Call(dc, uintptr(r.L), uintptr(r.T), uintptr(r.R), uintptr(r.B), uintptr(radius), uintptr(radius))
	gdi.NewProc("SelectObject").Call(dc, oldPen)
	gdi.NewProc("SelectObject").Call(dc, oldBrush)
	gdi.NewProc("DeleteObject").Call(brush)
}

func builderAppearance(h uintptr, m uint32, w, l uintptr) (uintptr, bool) {
	switch m {
	case 0x14:
		return 1, true
	case 0x0F:
		var ps paint
		dc, _, _ := user.NewProc("BeginPaint").Call(h, uintptr(unsafe.Pointer(&ps)))
		paintBuilder(dc)
		user.NewProc("EndPaint").Call(h, uintptr(unsafe.Pointer(&ps)))
		return 0, true
	case 0x133, 0x138:
		gdi.NewProc("SetTextColor").Call(w, ink)
		gdi.NewProc("SetBkColor").Call(w, editor)
		return editBrush, true
	case 0x2B:
		item := (*drawItem)(unsafe.Pointer(l))
		color, textColor := editor, ink
		if item.ID == 101 {
			color, textColor = accent, background
		}
		if item.State&1 != 0 {
			color = border
		}
		rounded(item.DC, item.R, color, 14)
		drawText(item.DC, textOf(item.Window), item.R, -17, textColor, 1|4|0x20)
		if item.State&0x10 != 0 {
			focus := item.R
			focus.L += 3
			focus.T += 3
			focus.R -= 3
			focus.B -= 3
			user.NewProc("DrawFocusRect").Call(item.DC, uintptr(unsafe.Pointer(&focus)))
		}
		return 1, true
	}
	return 0, false
}

func paintBuilder(dc uintptr) {
	w, h := 1000, 640
	fill(dc, rr(0, 0, w, h), background)
	fill(dc, rr(34, 28, 4, 51), accent)
	drawText(dc, "winlocker by softicdnb", rr(54, 23, 650, 36), -30, ink, 0x20)
	drawText(dc, "Собери свою последовательность из видеопримера", rr(54, 65, 650, 26), -17, soft, 0x20)
	rounded(dc, rr(806, 30, 160, 34), surface, 16)
	drawText(dc, "WINDOWS  ·  EXE", rr(806, 30, 160, 34), -14, accent, 1|4|0x20)
	fill(dc, rr(34, 103, 932, 1), border)
	for _, r := range []rect{rr(34, 140, 564, 42), rr(34, 212, 564, 152), rr(34, 400, 338, 44), rr(386, 400, 212, 44), rr(34, 476, 510, 44)} {
		rounded(dc, r, editor, 12)
	}
	drawText(dc, "ЗАГОЛОВОК СИНЕГО ЭКРАНА", rr(34, 115, 564, 24), -14, soft, 0x20)
	drawText(dc, "ТЕКСТ НА СИНЕМ ФОНЕ", rr(34, 187, 564, 24), -14, soft, 0x20)
	drawText(dc, "ПАРОЛЬ ДЛЯ ВЫХОДА", rr(34, 375, 338, 24), -14, soft, 0x20)
	drawText(dc, "СЕКУНД НА СЦЕНУ · 1–30", rr(386, 375, 222, 24), -14, soft, 0x20)
	drawText(dc, "СОХРАНИТЬ EXE", rr(34, 451, 564, 24), -14, soft, 0x20)
	drawText(dc, "Выход: пароль или Ctrl+Shift+Q. Esc / Alt+F4 / F11 — писк.", rr(34, 609, 620, 24), -15, soft, 0x20)
	// A live thumbnail of the configured DOS screen, with real text.
	drawText(dc, "СИНИЙ ЭКРАН · ПРЕДПРОСМОТР", rr(640, 115, 326, 24), -14, soft, 0x20)
	current := cfg
	if fields[3] != 0 {
		current.Title = textOf(fields[3])
	}
	if fields[4] != 0 {
		current.Body = textOf(fields[4])
	}
	drawRetro(dc, rr(640, 140, 326, 224), current, false, "DESKTOP")
	drawGPUArtifacts(dc, rr(640, 140, 326, 224), uint64(time.Now().UnixMilli()/300))
	rounded(dc, rr(640, 382, 326, 88), surface, 14)
	drawText(dc, "ЗВУК И ЭФФЕКТЫ", rr(658, 394, 290, 22), -13, accent, 0x20)
	drawText(dc, "Писк + артефакты", rr(658, 417, 290, 24), -18, ink, 0x20)
	drawText(dc, "Без музыки · синий экран", rr(658, 443, 290, 20), -14, soft, 0x20)
	drawText(dc, "ПОСЛЕДОВАТЕЛЬНОСТЬ", rr(640, 490, 326, 24), -14, soft, 0x20)
	for i, line := range []string{"01  Глаз и надпись + писк", "02  Строки ошибок", "03  Красная ASCII-сцена", "04  Синий экран + писк"} {
		drawText(dc, line, rr(640, 518+i*23, 326, 23), -15, ink, 0x20)
	}
}
