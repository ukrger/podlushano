package main

import "testing"

func TestArtifactFramesKeepPasswordEntryClear(t *testing.T) {
	left, right, top, bottom := 1280, 0, 720, 0
	for frame := uint64(0); frame < 2000; frame++ {
		ops := gpuArtifacts(frame)
		if len(ops) < 50 {
			t.Fatalf("frame %d unexpectedly empty", frame)
		}
		for _, op := range ops {
			if op.X < 0 || op.Y < 0 || op.W < 1 || op.H < 1 || op.X+op.W > 1280 || op.Y+op.H > 720 {
				t.Fatalf("frame %d: patch outside the scene: %+v", frame, op)
			}
			if op.X < 1016 && op.X+op.W > 267 && op.Y < 468 && op.Y+op.H > 444 {
				t.Fatalf("frame %d: patch covers password entry: %+v", frame, op)
			}
			if op.Copy && (op.X+op.Shift < 0 || op.X+op.W+op.Shift > 1280) {
				t.Fatalf("frame %d: source outside scene: %+v", frame, op)
			}
			left = min(left, op.X)
			right = max(right, op.X+op.W)
			top = min(top, op.Y)
			bottom = max(bottom, op.Y+op.H)
		}
	}
	if left > 20 || right < 1260 || top > 20 || bottom < 700 {
		t.Fatal("effect does not cover the full screen")
	}
}
