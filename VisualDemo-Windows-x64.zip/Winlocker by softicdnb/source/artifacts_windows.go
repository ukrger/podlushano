//go:build windows

package main

import "unsafe"

func drawGPUArtifacts(dc uintptr, bounds rect, frame uint64) {
	saved, _, _ := gdi.NewProc("SaveDC").Call(dc)
	defer gdi.NewProc("RestoreDC").Call(dc, saved)
	clip := retroRect(bounds, 235, 207, 870, 333)
	gdi.NewProc("IntersectClipRect").Call(dc, uintptr(clip.L), uintptr(clip.T), uintptr(clip.R), uintptr(clip.B))
	entry := retroRect(bounds, 267, 444, 749, 24)
	gdi.NewProc("ExcludeClipRect").Call(dc, uintptr(entry.L), uintptr(entry.T), uintptr(entry.R), uintptr(entry.B))
	brush, _, _ := gdi.NewProc("GetStockObject").Call(18) // DC_BRUSH
	for _, op := range gpuArtifacts(frame) {
		r := retroRect(bounds, op.X, op.Y, op.W, op.H)
		if op.Copy {
			source := retroRect(bounds, op.X+op.Shift, op.Y, op.W, op.H)
			gdi.NewProc("BitBlt").Call(dc, uintptr(r.L), uintptr(r.T), uintptr(r.R-r.L), uintptr(r.B-r.T), dc, uintptr(source.L), uintptr(source.T), 0xCC0020)
		} else {
			c := op.Color
			gdi.NewProc("SetDCBrushColor").Call(dc, rgb(int(c>>16&255), int(c>>8&255), int(c&255)))
			user.NewProc("FillRect").Call(dc, uintptr(unsafe.Pointer(&r)), brush)
		}
	}
}
