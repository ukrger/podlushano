package main

// Coordinates are relative to the 1280x720 reference scene.
// Effects are confined to the application surface and avoid the code entry box.
type artifactOp struct {
	X, Y, W, H int
	Shift      int
	Color      uint32
	Copy       bool
}

func gpuArtifacts(frame uint64) []artifactOp {
	seed := uint32(frame*0x9e3779b9) ^ 0xa87e193b
	next := func(n int) int {
		seed ^= seed << 13
		seed ^= seed >> 17
		seed ^= seed << 5
		return int(seed % uint32(n))
	}
	ops := make([]artifactOp, 0, 200)
	add := func(op artifactOp) {
		// Keep the native editable field legible and clickable in every frame.
		if op.X < 1016 && op.X+op.W > 267 && op.Y < 468 && op.Y+op.H > 444 {
			return
		}
		ops = append(ops, op)
	}
	palette := [...]uint32{0x00ff22, 0xff00ef, 0xffff00, 0x00ffff, 0xff9944, 0x223300, 0x10108a, 0x9900ff}
	for band := 0; band < 6; band++ {
		shift := next(37) - 18
		if shift == 0 {
			shift = 9
		}
		add(artifactOp{X: 268 + next(80), Y: 244 + next(270), W: 280 + next(380), H: 2 + next(7), Shift: shift, Copy: true})
	}
	for cluster := 0; cluster < 9; cluster++ {
		x, y := 238+next(760), 218+next(292)
		for row := 0; row < 4; row++ {
			for col := 0; col < 6; col++ {
				if next(4) == 0 {
					continue
				}
				add(artifactOp{X: x + col*6, Y: y + row*5, W: 4 + next(3), H: 3 + next(2), Color: palette[next(len(palette))]})
			}
		}
	}
	for line := 0; line < 7; line++ {
		add(artifactOp{X: 240 + next(690), Y: 222 + next(300), W: 22 + next(160), H: 1 + next(2), Color: palette[next(len(palette))]})
	}
	return ops
}
