//go:build windows

package main

import (
	"bytes"
	_ "embed"
	"image/png"
	"unsafe"
)

// These monochrome assets preserve the eye and ASCII silhouette in the user's video.
//
//go:embed assets/eye.png
var eyePNG []byte

//go:embed assets/reaper.png
var reaperPNG []byte

type raster struct {
	W, H   int
	Pixels []byte
}
type bitmapHeader struct {
	Size                   uint32
	W, H                   int32
	Planes, Bits           uint16
	Compression, ImageSize uint32
	XPels, YPels           int32
	Used, Important        uint32
}

func decodeRaster(data []byte, bg uintptr) raster {
	im, err := png.Decode(bytes.NewReader(data))
	if err != nil {
		panic(err)
	}
	w, h := im.Bounds().Dx(), im.Bounds().Dy()
	p := make([]byte, w*h*4)
	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			red, _, _, _ := im.At(x, y).RGBA()
			a := int(red >> 8)
			i := (y*w + x) * 4
			for ch := 0; ch < 3; ch++ {
				base := int((bg >> uint((2-ch)*8)) & 255)
				p[i+ch] = byte(base + (255-base)*a/255)
			}
		}
	}
	return raster{w, h, p}
}

var eyeRaster = decodeRaster(eyePNG, rgb(0, 0, 0))
var reaperRaster = decodeRaster(reaperPNG, rgb(144, 0, 0))

func blitRaster(dc uintptr, image raster, dest rect, fraction float64) {
	if fraction <= 0 {
		return
	}
	if fraction > 1 {
		fraction = 1
	}
	saved, _, _ := gdi.NewProc("SaveDC").Call(dc)
	gdi.NewProc("IntersectClipRect").Call(dc, uintptr(dest.L), uintptr(dest.T), uintptr(dest.R), uintptr(int(dest.T)+int(float64(dest.B-dest.T)*fraction)))
	info := bitmapHeader{Size: 40, W: int32(image.W), H: -int32(image.H), Planes: 1, Bits: 32}
	gdi.NewProc("SetStretchBltMode").Call(dc, 3)
	gdi.NewProc("StretchDIBits").Call(dc, uintptr(dest.L), uintptr(dest.T), uintptr(dest.R-dest.L), uintptr(dest.B-dest.T), 0, 0, uintptr(image.W), uintptr(image.H), uintptr(unsafe.Pointer(&image.Pixels[0])), uintptr(unsafe.Pointer(&info)), 0, 0xCC0020)
	gdi.NewProc("RestoreDC").Call(dc, saved)
}

func retroRect(bounds rect, x, y, w, h int) rect {
	bw, bh := int(bounds.R-bounds.L), int(bounds.B-bounds.T)
	return rr(int(bounds.L)+x*bw/1280, int(bounds.T)+y*bh/720, max(1, w*bw/1280), max(1, h*bh/720))
}
func retroFont(bounds rect, height int) int { return max(5, height*int(bounds.B-bounds.T)/720) }

func drawRetro(dc uintptr, bounds rect, c Config, badPassword bool, computer string) {
	white := rgb(240, 240, 240)
	fill(dc, bounds, rgb(0, 0, 0))
	fill(dc, retroRect(bounds, 67, 0, 1150, 720), rgb(0, 0, 255))
	fill(dc, retroRect(bounds, 480, 217, 322, 24), white)
	drawText(dc, c.Title, retroRect(bounds, 482, 218, 318, 23), retroFont(bounds, 18), rgb(0, 0, 0), 1|0x20|0x8000)
	outline(dc, retroRect(bounds, 260, 244, 763, 168), white)
	drawText(dc, c.Body, retroRect(bounds, 267, 247, 749, 162), retroFont(bounds, 18), white, 0x10)
	outline(dc, retroRect(bounds, 260, 417, 763, 88), white)
	drawText(dc, "Введите код разблокировки:", retroRect(bounds, 267, 420, 749, 24), retroFont(bounds, 20), white, 1|0x20)
	fill(dc, retroRect(bounds, 267, 444, 749, 24), white)
	if badPassword {
		drawText(dc, "Ошибка! Введённый код не совпадает с ключом разблокировки.", retroRect(bounds, 266, 477, 750, 22), retroFont(bounds, 16), rgb(255, 255, 70), 0x20)
	}
	drawText(dc, "Current PC: "+computer, retroRect(bounds, 260, 512, 550, 20), retroFont(bounds, 13), white, 0x20)
	drawText(dc, "Enter [Ввод]", retroRect(bounds, 864, 508, 158, 26), retroFont(bounds, 19), white, 2|0x20)
	drawText(dc, "ID: 10-42126250E14175", retroRect(bounds, 72, 699, 500, 18), retroFont(bounds, 12), white, 0x20)
}

func drawRetroControl(item *drawItem) {
	white := rgb(240, 240, 240)
	if item.ID == 203 {
		fill(item.DC, item.R, rgb(185, 0, 0))
		outline(item.DC, item.R, white)
		r := item.R
		r.L += 12
		r.R -= 12
		r.T += int32(max(12, int(r.B-r.T)/3))
		drawText(item.DC, cfg.Popup, r, max(12, int(item.R.B-item.R.T)*18/168), white, 1|0x10)
		return
	}
	color := rgb(0, 0, 0)
	if stage == 2 {
		color = rgb(144, 0, 0)
	}
	if stage == 3 {
		color = rgb(0, 0, 255)
	}
	fill(item.DC, item.R, color)
	drawText(item.DC, "[ Выход ]", item.R, 15, white, 1|4|0x20)
	if item.State&0x10 != 0 {
		user.NewProc("DrawFocusRect").Call(item.DC, uintptr(unsafe.Pointer(&item.R)))
	}
}
