//go:build windows

package main

import (
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"syscall"
	"time"
	"unsafe"
)

var (
	user                                = syscall.NewLazyDLL("user32.dll")
	gdi                                 = syscall.NewLazyDLL("gdi32.dll")
	kernel                              = syscall.NewLazyDLL("kernel32.dll")
	create                              = user.NewProc("CreateWindowExW")
	defproc                             = user.NewProc("DefWindowProcW")
	send                                = user.NewProc("SendMessageW")
	show                                = user.NewProc("ShowWindow")
	destroy                             = user.NewProc("DestroyWindow")
	invalidate                          = user.NewProc("InvalidateRect")
	getText                             = user.NewProc("GetWindowTextW")
	setText                             = user.NewProc("SetWindowTextW")
	messageBox                          = user.NewProc("MessageBoxW")
	instance                            uintptr
	builder, player, input, popupWindow uintptr
	cfg                                 = defaults()
	start                               time.Time
	lastBeep                            time.Time
	nextEyeBeep                         time.Time
	popupUntil                          time.Time
	popupVisible                        bool
	computerName                        string
	stage                               = -1
	invalidPassword                     bool
	fields                              = map[int]uintptr{}
	fonts                               = map[int]uintptr{}
	appBytes                            []byte
	preview                             bool
)

type rect struct{ L, T, R, B int32 }
type point struct{ X, Y int32 }
type msg struct {
	H       uintptr
	M       uint32
	W, L    uintptr
	Time    uint32
	Pt      point
	Private uint32
}
type wc struct {
	Size, Style                        uint32
	Proc                               uintptr
	ClsExtra, WndExtra                 int32
	Instance, Icon, Cursor, Background uintptr
	Menu, Name                         *uint16
	SmallIcon                          uintptr
}
type paint struct {
	DC              uintptr
	Erase           int32
	R               rect
	Restore, Update int32
	Reserved        [32]byte
}

func u(s string) *uint16      { return syscall.StringToUTF16Ptr(s) }
func rgb(r, g, b int) uintptr { return uintptr(r | g<<8 | b<<16) }
func makeWindow(class, title string, style uintptr, x, y, w, h int, parent, id uintptr) uintptr {
	result, _, _ := create.Call(0, uintptr(unsafe.Pointer(u(class))), uintptr(unsafe.Pointer(u(title))), style, uintptr(x), uintptr(y), uintptr(w), uintptr(h), parent, id, instance, 0)
	return result
}
func textOf(h uintptr) string {
	b := make([]uint16, 16002)
	n, _, _ := getText.Call(h, uintptr(unsafe.Pointer(&b[0])), uintptr(len(b)))
	return syscall.UTF16ToString(b[:int(n)])
}
func notify(s string) {
	messageBox.Call(builder, uintptr(unsafe.Pointer(u(s))), uintptr(unsafe.Pointer(u("winlocker by softicdnb"))), 0)
}
func font(size int) uintptr {
	if h := fonts[size]; h != 0 {
		return h
	}
	face := "Lucida Console"
	quality := uintptr(3)
	height := size
	if size < 0 {
		face = "Segoe UI"
		quality = 5
		height = -size
	}
	h, _, _ := gdi.NewProc("CreateFontW").Call(uintptr(height), 0, 0, 0, 400, 0, 0, 0, 1, 0, 0, quality, 0, uintptr(unsafe.Pointer(u(face))))
	fonts[size] = h
	return h
}
func control(class, text string, x, y, w, h int, id int, extra uintptr) uintptr {
	if class == "BUTTON" {
		extra |= 0x10000
	}
	c := makeWindow(class, text, 0x50000000|extra, x, y, w, h, builder, uintptr(id))
	send.Call(c, 0x30, font(-17), 1)
	return c
}
func label(text string, x, y, w, h int) { control("STATIC", text, x, y, w, h, 0, 0) }
func edit(id int, value string, x, y, w, h int, multi bool) {
	extra := uintptr(0x00010000 | 0x80)
	if multi {
		extra = 0x00010000 | 0x00200000 | 0x0004 | 0x0040 | 0x1000
	}
	value = strings.ReplaceAll(value, "\r\n", "\n")
	fields[id] = control("EDIT", strings.ReplaceAll(value, "\n", "\r\n"), x, y, w, h, id, extra)
	send.Call(fields[id], 0xD3, 3, 10|10<<16)
}
func startPlayer(c Config, isPreview bool) {
	cfg = c
	preview = isPreview
	stage = -1
	invalidPassword = false
	start = time.Now()
	w, _, _ := user.NewProc("GetSystemMetrics").Call(0)
	h, _, _ := user.NewProc("GetSystemMetrics").Call(1)
	player = makeWindow("VisualPlayer", cfg.Title, 0x82000000, 0, 0, int(w), int(h), 0, 0)
	if player == 0 {
		notify("Не удалось открыть окно показа")
		return
	}
	input = makeWindow("EDIT", "", 0x44010080, 0, 0, 100, 32, player, 201)
	send.Call(input, 0x30, font(22), 1)
	popupWindow = makeWindow("STATIC", "", 0x4400000D, 0, 0, 350, 168, player, 203)
	popupVisible = false
	popupUntil = time.Time{}
	if builder != 0 {
		show.Call(builder, 0)
	}
	audioError = startMusic()
	start = time.Now()
	lastBeep = time.Time{}
	nextEyeBeep = start.Add(2 * time.Second)
	show.Call(player, 5)
	beep()
	user.NewProc("SetTimer").Call(player, 1, 60, 0)
}
func beep() {
	if time.Since(lastBeep) < 180*time.Millisecond {
		return
	}
	lastBeep = time.Now()
	playBeep()
}

func signalExitAttempt() {
	if stage == 3 {
		popupUntil = time.Now().Add(3 * time.Second)
	}
	beep()
}
func checkPassword() {
	if textOf(input) == cfg.Password {
		destroy.Call(player)
		return
	}
	invalidPassword = true
	setText.Call(input, uintptr(unsafe.Pointer(u(""))))
	beep()
	invalidate.Call(player, 0, 0)
}
func dimensions(h uintptr) (int, int) {
	var r rect
	user.NewProc("GetClientRect").Call(h, uintptr(unsafe.Pointer(&r)))
	return int(r.R), int(r.B)
}
func fill(dc uintptr, r rect, color uintptr) {
	brush, _, _ := gdi.NewProc("CreateSolidBrush").Call(color)
	user.NewProc("FillRect").Call(dc, uintptr(unsafe.Pointer(&r)), brush)
	gdi.NewProc("DeleteObject").Call(brush)
}
func drawText(dc uintptr, text string, r rect, size int, color uintptr, flags uintptr) {
	old, _, _ := gdi.NewProc("SelectObject").Call(dc, font(size))
	gdi.NewProc("SetTextColor").Call(dc, color)
	gdi.NewProc("SetBkMode").Call(dc, 1)
	user.NewProc("DrawTextW").Call(dc, uintptr(unsafe.Pointer(u(text))), ^uintptr(0), uintptr(unsafe.Pointer(&r)), flags|0x800)
	gdi.NewProc("SelectObject").Call(dc, old)
}
func outline(dc uintptr, r rect, color uintptr) {
	fill(dc, rect{r.L, r.T, r.R, r.T + 1}, color)
	fill(dc, rect{r.L, r.B - 1, r.R, r.B}, color)
	fill(dc, rect{r.L, r.T, r.L + 1, r.B}, color)
	fill(dc, rect{r.R - 1, r.T, r.R, r.B}, color)
}
func rr(x, y, w, h int) rect { return rect{int32(x), int32(y), int32(x + w), int32(y + h)} }
func redraw(h uintptr) {
	var ps paint
	real, _, _ := user.NewProc("BeginPaint").Call(h, uintptr(unsafe.Pointer(&ps)))
	defer user.NewProc("EndPaint").Call(h, uintptr(unsafe.Pointer(&ps)))
	w, height := dimensions(h)
	if w <= 0 || height <= 0 {
		return
	}
	dc, _, _ := gdi.NewProc("CreateCompatibleDC").Call(real)
	bitmap, _, _ := gdi.NewProc("CreateCompatibleBitmap").Call(real, uintptr(w), uintptr(height))
	old, _, _ := gdi.NewProc("SelectObject").Call(dc, bitmap)
	defer func() {
		gdi.NewProc("SelectObject").Call(dc, old)
		gdi.NewProc("DeleteObject").Call(bitmap)
		gdi.NewProc("DeleteDC").Call(dc)
	}()
	age := time.Since(start).Seconds()
	seconds := float64(cfg.Seconds)
	current := int(age / seconds)
	if current > 3 {
		current = 3
	}
	bg := rgb(0, 0, 0)
	if current == 2 {
		bg = rgb(144, 0, 0)
	}
	if current == 3 {
		bg = rgb(0, 0, 255)
	}
	fill(dc, rr(0, 0, w, height), bg)
	white := rgb(240, 240, 240)
	red := rgb(255, 65, 65)
	if current != stage {
		stage = current
		if stage == 3 {
			ir := retroRect(rr(0, 0, w, height), 267, 444, 749, 24)
			user.NewProc("MoveWindow").Call(input, uintptr(ir.L), uintptr(ir.T), uintptr(ir.R-ir.L), uintptr(ir.B-ir.T), 1)
			send.Call(input, 0x30, font(retroFont(rr(0, 0, w, height), 20)), 1)
			pr := retroRect(rr(0, 0, w, height), 474, 301, 350, 168)
			user.NewProc("MoveWindow").Call(popupWindow, uintptr(pr.L), uintptr(pr.T), uintptr(pr.R-pr.L), uintptr(pr.B-pr.T), 1)
			show.Call(input, 5)
			fg, _, _ := user.NewProc("GetForegroundWindow").Call()
			if fg == h {
				user.NewProc("SetFocus").Call(input)
			}
			beep()
		}
	}
	switch current {
	case 0:
		drawText(dc, "Booting Windows . . .", rr(4, 0, w-8, 36), max(12, 24*height/720), white, 0x20)
		blitRaster(dc, eyeRaster, retroRect(rr(0, 0, w, height), 508, 300, 265, 127), min(1, age/0.5))
	case 1:
		lines := strings.Split(strings.ReplaceAll(cfg.Errors, "\r\n", "\n"), "\n")
		progress := (age - seconds) / seconds
		count := min(len(lines), int(progress*float64(len(lines)))+1)
		color := white
		if progress > 0.62 {
			color = red
		}
		drawText(dc, strings.Join(lines[:count], "\n"), rr(4, 0, w-8, height-30), max(12, 24*height/720), color, 0x10)
		blitRaster(dc, eyeRaster, retroRect(rr(0, 0, w, height), 508, 300, 265, 127), 1)
	case 2:
		progress := (age - 2*seconds) / min(seconds, 1.2)
		blitRaster(dc, reaperRaster, retroRect(rr(0, 0, w, height), 0, 32, 750, 529), progress)
	case 3:
		drawRetro(dc, rr(0, 0, w, height), cfg, invalidPassword, computerName)
		sceneAge := age - 3*seconds
		wantPopup := (sceneAge >= 2 && sceneAge < 5) || time.Now().Before(popupUntil)
		if wantPopup != popupVisible {
			popupVisible = wantPopup
			if wantPopup {
				user.NewProc("SetWindowPos").Call(popupWindow, 0, 0, 0, 0, 0, 0x13)
				show.Call(popupWindow, 5)
			} else {
				show.Call(popupWindow, 0)
			}
		}
	}
	if audioError != nil {
		drawText(dc, "Звук недоступен", rr(24, height-28, w-190, 24), 14, white, 0x20)
	}

	gdi.NewProc("BitBlt").Call(real, 0, 0, uintptr(w), uintptr(height), dc, 0, 0, 0x00CC0020)
}

func builderProc(h uintptr, m uint32, w, l uintptr) uintptr {
	if result, handled := builderAppearance(h, m, w, l); handled {
		return result
	}
	switch m {
	case 0x111:
		if (w >> 16) == 0x300 {
			invalidate.Call(h, 0, 0)
			return 0
		}
		switch int(w & 0xffff) {
		case 100, 101:
			c, err := readConfig()
			if err != nil {
				notify(err.Error())
				return 0
			}
			if int(w&0xffff) == 100 {
				startPlayer(c, true)
				return 0
			}
			path := strings.TrimSpace(textOf(fields[8]))
			if !strings.EqualFold(filepath.Ext(path), ".exe") {
				notify("Имя файла должно оканчиваться на .exe")
				return 0
			}
			data, err := pack(appBytes, c)
			if err == nil {
				err = writeExport(path, data)
			}
			if err != nil {
				notify(err.Error())
			} else {
				notify("Готово! EXE сохранён:\n" + path + "\n\nПароль: " + c.Password)
			}
			return 0
		case 103:
			chooseExportPath(h)
			return 0
		case 102:
			destroy.Call(h)
			return 0
		}
	case 2:
		user.NewProc("PostQuitMessage").Call(0)
		return 0
	}
	r, _, _ := defproc.Call(h, uintptr(m), w, l)
	return r
}
func playerProc(h uintptr, m uint32, w, l uintptr) uintptr {
	switch m {
	case 0x14:
		return 1
	case 0x0F:
		redraw(h)
		return 0
	case 0x2B:
		drawRetroControl((*drawItem)(unsafe.Pointer(l)))
		return 1
	case 0x113:
		if time.Since(start) < time.Duration(2*cfg.Seconds)*time.Second && !time.Now().Before(nextEyeBeep) {
			beep()
			nextEyeBeep = time.Now().Add(2 * time.Second)
		}
		invalidate.Call(h, 0, 0)
		return 0
	case 2:
		stopMusic()
		user.NewProc("KillTimer").Call(h, 1)
		player = 0
		input = 0
		popupWindow = 0
		if preview && builder != 0 {
			show.Call(builder, 5)
		} else {
			user.NewProc("PostQuitMessage").Call(0)
		}
		return 0
	}
	r, _, _ := defproc.Call(h, uintptr(m), w, l)
	return r
}
func main() {
	defer stopMusic()
	runtime.LockOSThread()
	computerName, _ = os.Hostname()
	user.NewProc("SetProcessDPIAware").Call()
	instance, _, _ = kernel.NewProc("GetModuleHandleW").Call(0)
	cursor, _, _ := user.NewProc("LoadCursorW").Call(0, 32512)
	for _, cls := range []struct {
		name string
		proc uintptr
	}{{"VisualBuilder", syscall.NewCallback(builderProc)}, {"VisualPlayer", syscall.NewCallback(playerProc)}} {
		c := wc{Size: uint32(unsafe.Sizeof(wc{})), Proc: cls.proc, Instance: instance, Cursor: cursor, Background: 16, Name: u(cls.name)}
		result, _, _ := user.NewProc("RegisterClassExW").Call(uintptr(unsafe.Pointer(&c)))
		if result == 0 {
			notify("Не удалось зарегистрировать окно")
			return
		}
	}
	exe, err := os.Executable()
	if err == nil {
		appBytes, err = os.ReadFile(exe)
	}
	if err != nil {
		notify(fmt.Sprint(err))
		return
	}
	_, embedded, err := unpack(appBytes)
	if err != nil {
		notify(err.Error())
		return
	}
	if embedded != nil {
		startPlayer(*embedded, false)
	} else {
		initBuilder()
	}
	var message msg
	for {
		r, _, _ := user.NewProc("GetMessageW").Call(uintptr(unsafe.Pointer(&message)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		// Only messages dispatched to this application's own window are handled.
		// No hooks, global hotkeys, or task-manager changes.
		// A local emergency shortcut remains available in every scene.
		ownsPlayerMessage := player != 0 && (message.H == player || message.H == input || message.H == popupWindow)
		if ownsPlayerMessage && message.M == 0x104 && message.W == 0x73 && message.L&(1<<29) != 0 {
			// Alt+F4 uses the same local feedback as Esc; ignore key repeats.
			if message.L&(1<<30) == 0 {
				signalExitAttempt()
			}
			continue
		}
		if ownsPlayerMessage && message.M == 0x100 {
			if message.W == 'Q' {
				ctrl, _, _ := user.NewProc("GetKeyState").Call(0x11)
				shift, _, _ := user.NewProc("GetKeyState").Call(0x10)
				if ctrl&0x8000 != 0 && shift&0x8000 != 0 {
					destroy.Call(player)
					continue
				}
			}
			if message.W == 0x1B || message.W == 0x7A {
				if message.L&(1<<30) != 0 {
					continue
				}
				signalExitAttempt()
				continue
			}
			if message.W == 0x0D && stage == 3 {
				checkPassword()
				continue
			}
		}
		if message.M == 0x100 && message.W == 9 {
			target := builder
			if player != 0 {
				target = player
			}
			done, _, _ := user.NewProc("IsDialogMessageW").Call(target, uintptr(unsafe.Pointer(&message)))
			if done != 0 {
				continue
			}
		}
		user.NewProc("TranslateMessage").Call(uintptr(unsafe.Pointer(&message)))
		user.NewProc("DispatchMessageW").Call(uintptr(unsafe.Pointer(&message)))
	}
	for _, brush := range []uintptr{builderBrush, editBrush} {
		if brush != 0 {
			gdi.NewProc("DeleteObject").Call(brush)
		}
	}
	for _, f := range fonts {
		gdi.NewProc("DeleteObject").Call(f)
	}
}
