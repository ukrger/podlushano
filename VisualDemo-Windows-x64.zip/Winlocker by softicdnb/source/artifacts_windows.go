//go:build windows

package main

import "unsafe"

var artifactBrushes [2]uintptr

func artifactBrush(layer int) uintptr {
	if artifactBrushes[layer] != 0 {
		return artifactBrushes[layer]
	}
	w, h, pixels := artifactPattern(layer)
	data := make([]byte, 40+len(pixels)*4)
	header := (*bitmapHeader)(unsafe.Pointer(&data[0]))
	*header = bitmapHeader{Size: 40, W: int32(w), H: -int32(h), Planes: 1, Bits: 32}
	for i, c := range pixels {
		data[40+i*4] = byte(c)
		data[41+i*4] = byte(c >> 8)
		data[42+i*4] = byte(c >> 16)
	}
	brush, _, _ := gdi.NewProc("CreateDIBPatternBrushPt").Call(uintptr(unsafe.Pointer(&data[0])), 0)
	artifactBrushes[layer] = brush
	return brush
}

func drawGPUArtifacts(dc uintptr, bounds rect, frame uint64) {
	saved, _, _ := gdi.NewProc("SaveDC").Call(dc)
	defer gdi.NewProc("RestoreDC").Call(dc, saved)
	clip := bounds
	gdi.NewProc("IntersectClipRect").Call(dc, uintptr(clip.L), uintptr(clip.T), uintptr(clip.R), uintptr(clip.B))
	entry := retroRect(bounds, 267, 444, 749, 24)
	gdi.NewProc("ExcludeClipRect").Call(dc, uintptr(entry.L), uintptr(entry.T), uintptr(entry.R), uintptr(entry.B))
	for layer := 0; layer < 2; layer++ {
		brush := artifactBrush(layer)
		if brush == 0 {
			continue
		}
		old, _, _ := gdi.NewProc("SelectObject").Call(dc, brush)
		x, y := int(frame%64), int((frame*2)%12)
		if layer == 1 {
			x = int((frame / 2) % 64)
			y = 0
		}
		gdi.NewProc("SetBrushOrgEx").Call(dc, uintptr(int(bounds.L)+x), uintptr(int(bounds.T)+y), 0)
		gdi.NewProc("PatBlt").Call(dc, uintptr(bounds.L), uintptr(bounds.T), uintptr(bounds.R-bounds.L), uintptr(bounds.B-bounds.T), 0x5A0049)
		gdi.NewProc("SelectObject").Call(dc, old)
	}
	brush, _, _ := gdi.NewProc("GetStockObject").Call(18) // DC_BRUSH
	for _, op := range gpuArtifacts(frame) {
		r := retroRect(bounds, op.X, op.Y, op.W, op.H)
		if op.Copy {
			source := retroRect(bounds, op.X+op.Shift, op.Y, op.W, op.H)
			gdi.NewProc("BitBlt").Call(dc, uintptr(r.L), uintptr(r.T), uintptr(r.R-r.L), uintptr(r.B-r.T), dc, uintptr(source.L), uintptr(source.T), 0xCC0020)
		} else {
			c := op.Color
			gdi.NewProc("SetDCBrushColor").Call(dc, rgb(int(c>>16&255), int(c>>8&255), int(c&255)))
			user.NewProc("FillRect").Call(dc, uintptr(unsafe.Pointer(&r)), brush)
		}
	}
}
