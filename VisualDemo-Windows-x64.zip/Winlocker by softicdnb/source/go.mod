module visualdemo

go 1.23
